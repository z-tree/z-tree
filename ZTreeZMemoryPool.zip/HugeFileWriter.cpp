#include "stdafx.h"
#include "HugeFileWriter.h"

CHugeFileWriter::CHugeFileWriter(void)
{
	m_pCache = NULL;
	m_nCacheSize = 0;
	m_nCacheContentSize = 0;
}

CHugeFileWriter::~CHugeFileWriter(void)
{
}

void CHugeFileWriter::InitCache(void)
{
	//100 MB
	if(m_pCache == NULL)
	{
		m_nCacheSize = 100000000;
		m_pCache = (unsigned char *)m_memoryPool.Malloc((size_t)m_nCacheSize);
	}
	m_nCacheContentSize = 0;
}

void CHugeFileWriter::DestroyCache(CFile& p_fileNewMapping)
{
	if(m_pCache == NULL)
	{
		return;
	}
	if(m_nCacheContentSize > 0)
	{
		p_fileNewMapping.Write(m_pCache, (UINT)m_nCacheContentSize);
		m_nCacheContentSize = 0;
	}
	m_memoryPool.Free(m_pCache);
	m_pCache = NULL;
	m_nCacheSize = 0;
	m_nCacheContentSize = 0;
}

void CHugeFileWriter::Write(CFile& p_fileNewMapping, const void * lpBuf, UINT nCount)
{
	//If the total size < cach size, just append to the cache
	if(m_nCacheContentSize + nCount < m_nCacheSize)
	{
		memcpy(m_pCache + m_nCacheContentSize, lpBuf, nCount);
		m_nCacheContentSize += nCount;
		return;
	}
	
	//If the incoming content size is less than cache size, write the existing content into file and append the incoming content to the cache
	if(nCount < m_nCacheSize)
	{
		if(m_nCacheContentSize > 0)
		{
			p_fileNewMapping.Write(m_pCache, (UINT)m_nCacheContentSize);
			m_nCacheContentSize = 0;
		}
		memcpy(m_pCache + m_nCacheContentSize, lpBuf, nCount);
		m_nCacheContentSize += nCount;
		return;
	}

	//The incoming content size is greater than cache size, write file content directly into the target file.
	if(m_nCacheContentSize > 0)
	{
		p_fileNewMapping.Write(m_pCache, (UINT)m_nCacheContentSize);
		m_nCacheContentSize = 0;
	}
	p_fileNewMapping.Write(lpBuf, nCount);
}
