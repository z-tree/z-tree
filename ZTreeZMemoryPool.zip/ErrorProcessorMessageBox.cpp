#include "stdafx.h"
#include "ErrorProcessorMessageBox.h"

CErrorProcessorMessageBox::CErrorProcessorMessageBox(void)
{
}

CErrorProcessorMessageBox::~CErrorProcessorMessageBox(void)
{
}

void CErrorProcessorMessageBox::ProcessErrorMsg(const char * p_pPointer)
{
	TCHAR 	wszTempBuffer[1000];
	int nLength = MultiByteToWideChar(CP_UTF8, 0, p_pPointer, (int)strlen(p_pPointer), wszTempBuffer, 1000 - 1);
	wszTempBuffer[nLength] = 0X00;
	AfxMessageBox(wszTempBuffer);
}
