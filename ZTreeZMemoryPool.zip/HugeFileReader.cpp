#include "StdAfx.h"
#include "HugeFileReader.h"

CHugeFileReader::CHugeFileReader(void)
{
	hFile1Mapping = NULL;
	hFile1 = NULL;
	m_nFile1Size = -1;
}

CHugeFileReader::~CHugeFileReader(void)
{
}

BOOL CHugeFileReader::OpenFile(CString p_sFileName)
{
	hFile1 = CreateFile(p_sFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)0);
	if(hFile1 == NULL)
	{
		CString sMessage;
		GetErrorMessage(sMessage);
		AfxMessageBox(sMessage, MB_ICONERROR | MB_OK);
		return FALSE;
	}

	
	ASSERT(sizeof(DWORD) == 4);
	DWORD *pFile1SizeLower = ((DWORD *)&m_nFile1Size);
	DWORD *pFile1SizeHeigher = (DWORD *)&m_nFile1Size + 1;
	*pFile1SizeLower = ::GetFileSize(hFile1, pFile1SizeHeigher);

	hFile1Mapping  =  CreateFileMapping(hFile1,  NULL,  PAGE_READONLY,  0,  0,  NULL); 
	if(m_nFile1Size > 0 && hFile1Mapping == NULL)
	{
		AfxMessageBox(_T("Fail to create file mapping!"), MB_ICONERROR | MB_OK);
		CloseHandle(hFile1);
		return FALSE;
	}
	return TRUE;
}

Z_INT64 CHugeFileReader::GetFileSize(void)
{
	return m_nFile1Size;
}

Z_INT64 CHugeFileReader::Read(void * p_pBuffer, Z_INT64& p_nOffset, Z_INT64& p_nSize)
{
	//Align the offset and size with ENC_DEC_BUF_SIZE
	p_nOffset = p_nOffset / ENC_DEC_BUF_SIZE * ENC_DEC_BUF_SIZE;
	p_nSize = p_nSize / ENC_DEC_BUF_SIZE * ENC_DEC_BUF_SIZE;

	Z_INT64 nFileOffset = p_nOffset;
	DWORD *pFileOffsetLower = ((DWORD *)&nFileOffset);
	DWORD *pFileOffsetHeigher = (DWORD *)&nFileOffset + 1;

	if(nFileOffset >= m_nFile1Size)
	{
		return -1;
	}
	
	Z_INT64 nMapSize = p_nSize;
	if(m_nFile1Size - nFileOffset < p_nSize)
	{
		nMapSize = m_nFile1Size - nFileOffset;
	}

	void * pFile1Mapping = MapViewOfFile(hFile1Mapping,  FILE_MAP_READ,  *pFileOffsetHeigher,  *pFileOffsetLower,  (unsigned int)nMapSize);
	if(pFile1Mapping == NULL)
	{
		CString sMessage;
		GetErrorMessage(sMessage);
		AfxMessageBox(sMessage, MB_ICONERROR | MB_OK);
		return -1;
	}
	else
	{
		//Copy data
		memcpy(p_pBuffer, pFile1Mapping, (size_t)nMapSize);
		//if(nMapSize < p_nSize)
		//{
		//	memset(((char *)p_pBuffer) + nMapSize, 0x00, (size_t)(p_nSize - nMapSize));
		//}
	}

	UnmapViewOfFile(pFile1Mapping);
	return nMapSize;
}

void CHugeFileReader::CloseFile(void)
{
	if(hFile1Mapping != NULL)
	{
		CloseHandle(hFile1Mapping);
		hFile1Mapping = NULL;
	}
	if(hFile1 != NULL)
	{
		CloseHandle(hFile1);
		hFile1 = NULL;
	}
}

void CHugeFileReader::GetErrorMessage(CString & p_sMessage)
{
	int nErrorCode = GetLastError();
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		nErrorCode,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
		);
	// Display the string.
	p_sMessage = (LPCTSTR)lpMsgBuf;
	// Free the buffer.
	LocalFree(lpMsgBuf);
}
