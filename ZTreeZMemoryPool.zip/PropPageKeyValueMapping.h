#pragma once


// CPropPageKeyValueMapping dialog
#include "ZTree\ZTreeOneValue.h"
#include "ZTree\ZTreeValueList.h"


class CPropPageKeyValueMapping : public CPropertyPage
{
	DECLARE_DYNAMIC(CPropPageKeyValueMapping)

public:
	CPropPageKeyValueMapping();
	virtual ~CPropPageKeyValueMapping();

// Dialog Data
	enum { IDD = IDD_DLG_KEY_VALUE_MAPPING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnKeyValueMappingOneToOne();
	afx_msg void OnBnClickedBtnKeyValueMappingOneToMany();
};
