#pragma once


#include "PropPageSort.h"
#include "PropPageKeyValueMapping.h"
#include "PropPageLongestCommonString.h"
#include "PropPageMemoryPool.h"


// CPropSheetZTreeDemo

class CPropSheetZTreeDemo : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropSheetZTreeDemo)

public:
	CPropSheetZTreeDemo(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CPropSheetZTreeDemo(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	virtual ~CPropSheetZTreeDemo();

public:
	static const int	MAX_TITLE_LENGTH = 100;

	CPropPageSort m_propPageSort;
	TCHAR			m_wszSortTitle[MAX_TITLE_LENGTH];
	CPropPageKeyValueMapping m_propPageKeyValueMapping;
	TCHAR			m_wszKeyValueMappingTitle[MAX_TITLE_LENGTH];
	CPropPageMemoryPool m_propPageMemoryPool;
	TCHAR			m_wszMemoryPoolTitle[MAX_TITLE_LENGTH];
	CPropPageLongestCommonString m_propPageLongestCommonString;
	TCHAR			m_wszLongestCommonStringTitle[MAX_TITLE_LENGTH];
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnHelp();
};


