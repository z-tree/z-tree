#include "StdAfx.h"
#include "SortFile.h"

unsigned char CSortFile::m_szCleanHeadBitsMask[ZTREE_BITS_NUMBER_PER_CHAR] = {0XFF, 0X7F, 0X3F, 0X1F, 0X0F, 0X07, 0X03, 0X01};

CSortFile::CSortFile(void)
{
	m_pLineBuffer = NULL;
	m_nLineBufferSizeInBit = 0;
}

CSortFile::~CSortFile(void)
{
}

Z_INT64 CSortFile::ReadFileIntoZTree(unsigned char * pLineBuffer, CString p_sSourceFileName, CZTreeNoValue& p_zTree)
{
	CHugeFileReader hugeFileReader;
	if(!hugeFileReader.OpenFile(p_sSourceFileName))
	{
		hugeFileReader.CloseFile();
		return -1;
	}
	
	//Load lines into Z-Tree
	unsigned char * pFileMapping = pLineBuffer + READ_FILE_BLOCK_SIZE;
	unsigned char * pLineStart = pFileMapping;
	unsigned char * pContentEnd = pFileMapping;
	Z_INT64 nOffset = 0;
	Z_INT64 nSize = READ_FILE_BLOCK_SIZE;
	nSize = hugeFileReader.Read(pFileMapping, nOffset, nSize);
	BOOL bIsDOSFile = true;
	while(nSize > 0)
	{
		pContentEnd += nSize;
		nOffset += nSize;
		
		unsigned char * pLineEnd = pLineStart;
		while(pLineEnd < pContentEnd)
		{
			while(pLineEnd < pContentEnd && *pLineEnd != '\n')
			{
				pLineEnd++;
			}
			if(*pLineEnd == '\n')
			{
				if((pLineEnd > pLineStart) && *(pLineEnd - 1) == '\r')
				{
					bIsDOSFile = true;
				}
				else
				{
					bIsDOSFile = false;
				}
				//insert line into Z-Tree
				pLineEnd++;
				p_zTree.AddKeyValue(pLineStart, pLineEnd - pLineStart, NULL);
				pLineStart = pLineEnd;
			}
			else
			{
				//A line is longer than READ_FILE_BLOCK_SIZE
				if(pContentEnd - pLineStart >= READ_FILE_BLOCK_SIZE)
				{
					p_zTree.AddKeyValue(pLineStart, READ_FILE_BLOCK_SIZE, NULL);
					pLineStart += READ_FILE_BLOCK_SIZE;
				}
				break;
			}
		}
		
		//Copy the remaining content before pFileMapping
		memcpy(pFileMapping - (pContentEnd - pLineStart), pLineStart, pContentEnd - pLineStart);
		pLineStart = pFileMapping - (pContentEnd - pLineStart);
		pContentEnd = pFileMapping;
		
		//Read the next block
		if(nSize < READ_FILE_BLOCK_SIZE)
		{
			break;
		}
		nSize = READ_FILE_BLOCK_SIZE;
		nSize = hugeFileReader.Read(pFileMapping, nOffset, nSize);
	}
	//Insert the remaining content into Z-Tree
	if(pContentEnd > pLineStart)
	{
		//Need to append an extra carriage return here
		if(bIsDOSFile)
		{
			*pContentEnd = '\r';
			pContentEnd++;
			*pContentEnd = '\n';
			pContentEnd++;
		}
		else
		{
			*pContentEnd = '\n';
			pContentEnd++;
		}
		p_zTree.AddKeyValue(pLineStart, pContentEnd - pLineStart, NULL);
	}
	

	return nOffset;
}


void CSortFile::GetValueFromKeyNode(unsigned char * pLineBuffer, unsigned int & p_nBufferIndexInBit, ZTREE_KEY_NODE * p_nZTreeShareKeys)
{

	unsigned int nIndex = p_nBufferIndexInBit / ZTREE_BITS_NUMBER_PER_CHAR;
	unsigned int 		nTreeLevelIndex = p_nBufferIndexInBit % ZTREE_BITS_NUMBER_PER_CHAR;
	
	unsigned int 	nKeyStartIndex = p_nZTreeShareKeys->m_nBitLevelStart / ZTREE_BITS_NUMBER_PER_CHAR;
	unsigned int			nKeyTreeLevelStartIndex = p_nZTreeShareKeys->m_nBitLevelStart % ZTREE_BITS_NUMBER_PER_CHAR;
	unsigned int	nKeyEndIndex = (p_nZTreeShareKeys->m_nBitLevelEnd + ZTREE_BITS_NUMBER_PER_CHAR - 1) / ZTREE_BITS_NUMBER_PER_CHAR;
	if(p_nBufferIndexInBit + ((p_nZTreeShareKeys->m_nBitLevelEnd - p_nZTreeShareKeys->m_nBitLevelStart)) > m_nLineBufferSizeInBit)
	{
		printf("GetValueFromKeyNode: Buffer size too small");
		return;
	}
	if(nTreeLevelIndex  != nKeyTreeLevelStartIndex)
	{
		printf("GetValueFromKeyNode: p_nZTreeShareKeys->m_nBitLevelStart doesn't match!");
		return;
	}
	
	//Copy value from the right half of the start char
	pLineBuffer[nIndex] &= ~m_szCleanHeadBitsMask[nKeyTreeLevelStartIndex];
	pLineBuffer[nIndex] |= (p_nZTreeShareKeys->m_pKey[nKeyStartIndex] & m_szCleanHeadBitsMask[nKeyTreeLevelStartIndex]);
	
	//Copy the middle TCHARs together the end char. The end char will be clean some bits in the next step
	for(unsigned int i = nKeyStartIndex + 1; i < nKeyEndIndex; i++)
	{
		nIndex += 1;
		pLineBuffer[nIndex] = p_nZTreeShareKeys->m_pKey[i];
	}
	
	//update p_nBufferIndexInBit
	p_nBufferIndexInBit += (p_nZTreeShareKeys->m_nBitLevelEnd - p_nZTreeShareKeys->m_nBitLevelStart);
	return;
}


void CSortFile::GetValueFromBranchNode(unsigned char * pLineBuffer, unsigned int & p_nBufferIndexInBit, int p_nBitValue)
{
	if(p_nBufferIndexInBit >= m_nLineBufferSizeInBit)
	{
		printf("GetValueFromBranchNode: Buffer size too small %d--%d\r\n", p_nBufferIndexInBit);
		return;
	}
	
	int nCharIndex = p_nBufferIndexInBit / ZTREE_BITS_NUMBER_PER_CHAR;
	int nBitIndex = p_nBufferIndexInBit % ZTREE_BITS_NUMBER_PER_CHAR;
	//if(p_nBitValue == 1) set bit value to 1 else set the bit value to 0
	if(p_nBitValue == 1)
	{
		pLineBuffer[nCharIndex] |= CZTreeBase::m_uchBitsMask[nBitIndex];
	}
	else
	{
		pLineBuffer[nCharIndex] &= ~CZTreeBase::m_uchBitsMask[nBitIndex];
	}
	p_nBufferIndexInBit++;
	return;	
}

Z_INT64 CSortFile::WriteResultInAscendingOrder(void * p_pNode, unsigned int p_nBufferIndexInBit)
{
	if(p_pNode == NULL)
	{
		return 0;
	}

	//Fill in value for node ZTREE_KEY_NODE
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag != ZTREE_IS_BRANCH_NODE)
	{
		GetValueFromKeyNode((unsigned char *)m_pLineBuffer, p_nBufferIndexInBit, (ZTREE_KEY_NODE *)p_pNode);
	}
	
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nValue > 0)
		{
			for(int i = 0; i < ((ZTREE_BRANCH_NODE *)p_pNode)->m_nValue; i++)
			{
				m_hugeFileWriter.Write(m_fileSortResult, m_pLineBuffer, p_nBufferIndexInBit / ZTREE_BITS_NUMBER_PER_CHAR);
			}
		}
	}
	else
	{
		if(((ZTREE_KEY_NODE *)p_pNode)->m_nValue > 0)
		{
			for(int i = 0; i < ((ZTREE_KEY_NODE *)p_pNode)->m_nValue; i++)
			{
				m_hugeFileWriter.Write(m_fileSortResult, m_pLineBuffer, p_nBufferIndexInBit / ZTREE_BITS_NUMBER_PER_CHAR);
			}
		}
	}

	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		if(p_nBufferIndexInBit < m_nLineBufferSizeInBit)
		{
			unsigned int nBufferIndexInBit;
			nBufferIndexInBit = p_nBufferIndexInBit;
			GetValueFromBranchNode((unsigned char *)m_pLineBuffer, nBufferIndexInBit, 0);
			WriteResultInAscendingOrder(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0], nBufferIndexInBit);
			
			nBufferIndexInBit = p_nBufferIndexInBit;
			GetValueFromBranchNode((unsigned char *)m_pLineBuffer, nBufferIndexInBit, 1);
			WriteResultInAscendingOrder(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1], nBufferIndexInBit);
		}
	}
	else
	{
		WriteResultInAscendingOrder(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode, p_nBufferIndexInBit);
	}

	return 1;	
}


Z_INT64 CSortFile::WriteResultInDescendingOrder(void * p_pNode, unsigned int p_nBufferIndexInBit)
{
	if(p_pNode == NULL)
	{
		return 0;
	}

	//Fill in value for node ZTREE_KEY_NODE
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag != ZTREE_IS_BRANCH_NODE)
	{
		GetValueFromKeyNode((unsigned char *)m_pLineBuffer, p_nBufferIndexInBit, (ZTREE_KEY_NODE *)p_pNode);
	}

	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		if(p_nBufferIndexInBit < m_nLineBufferSizeInBit)
		{
			unsigned int nBufferIndexInBit;			
			nBufferIndexInBit = p_nBufferIndexInBit;
			GetValueFromBranchNode((unsigned char *)m_pLineBuffer, nBufferIndexInBit, 1);
			WriteResultInDescendingOrder(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1], nBufferIndexInBit);

			nBufferIndexInBit = p_nBufferIndexInBit;
			GetValueFromBranchNode((unsigned char *)m_pLineBuffer, nBufferIndexInBit, 0);
			WriteResultInDescendingOrder(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0], nBufferIndexInBit);
		}
	}
	else
	{
		WriteResultInDescendingOrder(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode, p_nBufferIndexInBit);
	}
	
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nValue > 0)
		{
			for(int i = 0; i < ((ZTREE_BRANCH_NODE *)p_pNode)->m_nValue; i++)
			{
				m_hugeFileWriter.Write(m_fileSortResult, m_pLineBuffer, p_nBufferIndexInBit / ZTREE_BITS_NUMBER_PER_CHAR);
			}
		}
	}
	else
	{
		if(((ZTREE_KEY_NODE *)p_pNode)->m_nValue > 0)
		{
			for(int i = 0; i < ((ZTREE_KEY_NODE *)p_pNode)->m_nValue; i++)
			{
				m_hugeFileWriter.Write(m_fileSortResult, m_pLineBuffer, p_nBufferIndexInBit / ZTREE_BITS_NUMBER_PER_CHAR);
			}
		}
	}

	return 1;	
}


Z_INT64 CSortFile::SortInAscendingOrder(CString p_sSourceFileName, CString p_sTargetFileName)
{
	//1. Allocate Line Buffer
	CZMemoryPool memoryPool;
	m_pLineBuffer = (unsigned char *)memoryPool.Malloc(READ_FILE_BLOCK_SIZE * 2);
	

	//2. Read source file into Z-Tree
	CZTreeNoValue zTree;
	zTree.InitZTree();
	if(ReadFileIntoZTree(m_pLineBuffer, p_sSourceFileName, zTree) < 0)
	{
		return -1;
	}


	//3. Write sorting result into p_sTargetFileName
	CFileException eFile;
	if(!m_fileSortResult.Open(p_sTargetFileName, CFile::modeCreate | CFile::modeReadWrite | CFile::shareExclusive, &eFile))
	{
		CString sMessage;
		GetErrorMessage(sMessage);
		AfxMessageBox(sMessage, MB_ICONERROR | MB_OK);
		return -1;
	}
	m_hugeFileWriter.InitCache();
	//m_nLineBufferSizeInBit is the bit number of the buffer
	m_nLineBufferSizeInBit = READ_FILE_BLOCK_SIZE * ZTREE_BITS_NUMBER_PER_CHAR;
	unsigned int p_nBufferIndexInBit = 0;
	WriteResultInAscendingOrder(zTree.GetRootNode(), p_nBufferIndexInBit);
	m_hugeFileWriter.DestroyCache(m_fileSortResult);


	//4. Call CZMemoryPool.Free() to free memory and check memory overflow
	zTree.ReleaseZTree(FALSE);
	memoryPool.Free(m_pLineBuffer);
	m_pLineBuffer = NULL;

	//5. It is done.
	AfxMessageBox(_T("It is done!"), MB_OK);
	return 0;
}

Z_INT64 CSortFile::SortInDescendingOrder(CString p_sSourceFileName, CString p_sTargetFileName)
{
	//1. Allocate Line Buffer
	CZMemoryPool memoryPool;
	m_pLineBuffer = (unsigned char *)memoryPool.Malloc(READ_FILE_BLOCK_SIZE * 2);
	

	//2. Read source file into Z-Tree
	CZTreeNoValue zTree;
	zTree.InitZTree();
	if(ReadFileIntoZTree(m_pLineBuffer, p_sSourceFileName, zTree) < 0)
	{
		return -1;
	}


	//3. Write sorting result into p_sTargetFileName
	CFileException eFile;
	if(!m_fileSortResult.Open(p_sTargetFileName, CFile::modeCreate | CFile::modeReadWrite | CFile::shareExclusive, &eFile))
	{
		CString sMessage;
		GetErrorMessage(sMessage);
		AfxMessageBox(sMessage, MB_ICONERROR | MB_OK);
		return -1;
	}
	m_hugeFileWriter.InitCache();
	//m_nLineBufferSizeInBit is the bit number of the buffer
	m_nLineBufferSizeInBit = READ_FILE_BLOCK_SIZE * ZTREE_BITS_NUMBER_PER_CHAR;
	unsigned int p_nBufferIndexInBit = 0;
	WriteResultInDescendingOrder(zTree.GetRootNode(), p_nBufferIndexInBit);
	m_hugeFileWriter.DestroyCache(m_fileSortResult);


	//4. Call CZMemoryPool.Free() to free memory and check memory overflow
	zTree.ReleaseZTree(FALSE);
	memoryPool.Free(m_pLineBuffer);
	m_pLineBuffer = NULL;

	//5. It is done.
	AfxMessageBox(_T("It is done!"), MB_OK);
	return 0;
}



void CSortFile::GetErrorMessage(CString & p_sMessage)
{
	int nErrorCode = GetLastError();
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		nErrorCode,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
		);
	// Display the string.
	p_sMessage = (LPCTSTR)lpMsgBuf;
	// Free the buffer.
	LocalFree(lpMsgBuf);
}
