#pragma once

#include "ErrorProcessorMessageBox.h"

// CPropPageMemoryPool dialog

class CPropPageMemoryPool : public CPropertyPage
{
	DECLARE_DYNAMIC(CPropPageMemoryPool)

public:
	CPropPageMemoryPool();
	virtual ~CPropPageMemoryPool();

// Dialog Data
	enum { IDD = IDD_DLG_MEMORY_POOL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnMalloc();
	afx_msg void OnBnClickedBtnDetectUnreleasedMemory();

private:
	static CErrorProcessorMessageBox errorProcessorMessageBox;
public:
	afx_msg void OnBnClickedBtnDetectMemoryOverflow();
};
