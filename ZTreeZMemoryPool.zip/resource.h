//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ZTreeZMemoryPool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ZTREEZMEMORYPOOL_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_DLG_MEMORY_POOL             129
#define IDD_DLG_SORT                    130
#define IDD_DLG_KEY_VALUE_MAPPING       131
#define IDD_DLG_LONGEST_COMMON_SUBSTRING 132
#define IDR_MENU1                       133
#define IDR_MENU_ABOUT                  133
#define IDC_BUTTON1                     1000
#define IDC_BTN_MALLOC                  1000
#define IDC_BTN_MALLOC2                 1001
#define IDC_BTN_DETECT_UNRELEASED_MEMORY 1001
#define IDC_BTN_SORT_IN_ASCENDING_ORDER 1001
#define IDC_BTN_DETECT_MEMORY_OVERFLOW  1002
#define IDC_BTN_SORT_IN_ASCENDING_ORDER2 1002
#define IDC_BTN_SORT_IN_DESCENDING_ORDER 1002
#define IDC_BTN_KEY_VALUE_MAPPING_ONE_TO_ONE 1003
#define IDC_BTN_KEY_VALUE_MAPPING_ONE_TO_MANY 1004
#define IDC_BTN_LOAC_FILE_INTO_Z_TREE   1005
#define IDC_EDIT_TARGET_STRING          1006
#define IDC_EDIT_TARGET_STRING2         1007
#define IDC_EDIT_LONGEST_COMMON_SUBSTRING 1007
#define ID_HELP_ABOUT                   32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
