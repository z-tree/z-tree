#pragma once


// CPropPageLongestCommonString dialog
#include "ZTree\ZTreeNoValue.h"

class CPropPageLongestCommonString : public CPropertyPage
{
	DECLARE_DYNAMIC(CPropPageLongestCommonString)

public:
	CPropPageLongestCommonString();
	virtual ~CPropPageLongestCommonString();

// Dialog Data
	enum { IDD = IDD_DLG_LONGEST_COMMON_SUBSTRING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
public:
	afx_msg void OnBnClickedBtnLoacFileIntoZTree();

private:
	CZTreeNoValue m_zTree;
	static const int MAX_KEY_LENGTH = 1000;
	static const int BITS_PER_CHAR = 8;
public:
	afx_msg void OnEnChangeEditTargetString();
};
