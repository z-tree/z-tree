#pragma once


// CPropPageSort dialog

class CPropPageSort : public CPropertyPage
{
	DECLARE_DYNAMIC(CPropPageSort)

public:
	CPropPageSort();
	virtual ~CPropPageSort();

// Dialog Data
	enum { IDD = IDD_DLG_SORT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnSortInAscendingOrder();
	afx_msg void OnBnClickedBtnSortInDescendingOrder();
};
