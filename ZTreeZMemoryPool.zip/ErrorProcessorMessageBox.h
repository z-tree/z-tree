#ifndef _ZTREE_ERROR_PROCESSOR_MESSAGEBOX_H_
#define _ZTREE_ERROR_PROCESSOR_MESSAGEBOX_H_

#include "ZTree\ZErrorProcessorBase.h"

class CErrorProcessorMessageBox :
	public CZErrorProcessorBase
{
public:
	CErrorProcessorMessageBox(void);
	~CErrorProcessorMessageBox(void);

	void ProcessErrorMsg(const char * p_pPointer);
};

#endif
