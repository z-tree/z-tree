#pragma once

#include "ZTree\ZCommon.h"

class CHugeFileReader
{
public:
	CHugeFileReader(void);
	virtual ~CHugeFileReader(void);
	BOOL OpenFile(CString p_sFileName);
	Z_INT64 GetFileSize(void);

	/**
	 * This function reads from the file and returns the actual size. 
	 * If there is no content to read or something is wrong, this function returns -1.
	 * 
	 * p_pBuffer is the buffer for return data.
	 * p_nOffset is the start position to read from the file. p_nOffset should be n * 16K.
	 * p_nSize is the size to read from the file. p_nSize should be n * 16K.
	 * 
	 */
	Z_INT64 Read(void * p_pBuffer, Z_INT64& p_nOffset, Z_INT64& p_nSize);
	void CloseFile(void);

private:
	static const int ENC_DEC_BUF_SIZE = 16384;
	
	
	HANDLE hFile1;
	HANDLE hFile1Mapping;
	Z_INT64 m_nFile1Size;

	void GetErrorMessage(CString & p_sMessage);
public:
	
};
