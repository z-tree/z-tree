// PropPageSort.cpp : implementation file
//

#include "stdafx.h"
#include "ZTreeZMemoryPool.h"
#include "PropPageSort.h"
#include "SortFile.h"


// CPropPageSort dialog

IMPLEMENT_DYNAMIC(CPropPageSort, CPropertyPage)

CPropPageSort::CPropPageSort()
	: CPropertyPage(CPropPageSort::IDD)
{

}

CPropPageSort::~CPropPageSort()
{
}

void CPropPageSort::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPropPageSort, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_SORT_IN_ASCENDING_ORDER, &CPropPageSort::OnBnClickedBtnSortInAscendingOrder)
	ON_BN_CLICKED(IDC_BTN_SORT_IN_DESCENDING_ORDER, &CPropPageSort::OnBnClickedBtnSortInDescendingOrder)
END_MESSAGE_MAP()


// CPropPageSort message handlers

void CPropPageSort::OnBnClickedBtnSortInAscendingOrder()
{
	// TODO: Add your control notification handler code here
	CFileDialog dlgFile(TRUE);
	if(dlgFile.DoModal() == IDOK)
	{
		CString sFileName = dlgFile.GetPathName();
		CSortFile sortFileInAscendingOrder;
		sortFileInAscendingOrder.SortInAscendingOrder(sFileName, sFileName + _T(".asc"));
	}
}

void CPropPageSort::OnBnClickedBtnSortInDescendingOrder()
{
	// TODO: Add your control notification handler code here
	CFileDialog dlgFile(TRUE);
	if(dlgFile.DoModal() == IDOK)
	{
		CString sFileName = dlgFile.GetPathName();
		CSortFile sortFileInAscendingOrder;
		sortFileInAscendingOrder.SortInDescendingOrder(sFileName, sFileName + _T(".desc"));
	}
}
