// PropPageMemoryPool.cpp : implementation file
//

#include "stdafx.h"
#include "ZTreeZMemoryPool.h"
#include "PropPageMemoryPool.h"
#include "ZTree\ZErrorProcessorBase.h"
#include "ZTree\ZMemoryPool.h"


// CPropPageMemoryPool dialog
CErrorProcessorMessageBox CPropPageMemoryPool::errorProcessorMessageBox;

IMPLEMENT_DYNAMIC(CPropPageMemoryPool, CPropertyPage)

CPropPageMemoryPool::CPropPageMemoryPool()
	: CPropertyPage(CPropPageMemoryPool::IDD)
{

}

CPropPageMemoryPool::~CPropPageMemoryPool()
{
}

void CPropPageMemoryPool::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPropPageMemoryPool, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_MALLOC, &CPropPageMemoryPool::OnBnClickedBtnMalloc)
	ON_BN_CLICKED(IDC_BTN_DETECT_UNRELEASED_MEMORY, &CPropPageMemoryPool::OnBnClickedBtnDetectUnreleasedMemory)
	ON_BN_CLICKED(IDC_BTN_DETECT_MEMORY_OVERFLOW, &CPropPageMemoryPool::OnBnClickedBtnDetectMemoryOverflow)
END_MESSAGE_MAP()


// CPropPageMemoryPool message handlers

void CPropPageMemoryPool::OnBnClickedBtnMalloc()
{
	// TODO: Add your control notification handler code here
	CZMemoryPool memoryPool;
	for(int i = 0; i < 10000000; i++)
	{
		char * pMemory = (char *)memoryPool.Malloc(4);
	}
	MessageBox(_T("Finished!"));
}

void CPropPageMemoryPool::OnBnClickedBtnDetectUnreleasedMemory()
{
	// TODO: Add your control notification handler code here
	/*
	 * CZErrorProcessorBase::SetProcessError(CZErrorProcessorBase * p_pCZErrorProcessorBase) is not multi-thread safe.
	 * It is recommended to define CErrorProcessorMessageBox as a static variable and call CZErrorProcessorBase::SetProcessError(CZErrorProcessorBase * p_pCZErrorProcessorBase) only once when the application starts.
	 * We call CZErrorProcessorBase::SetProcessError(CZErrorProcessorBase * p_pCZErrorProcessorBase) here just for demonstration.
	 * In the following example, we added { and } to ensure the destructor of CZMemoryPool is called before calling CZErrorProcessorBase::SetProcessError(NULL).
	 */
	{
		CZErrorProcessorBase::SetProcessError(&errorProcessorMessageBox);
		CZMemoryPool memoryPool;
		char * pMemory = (char *)memoryPool.Malloc(4);
		//We will see error message if we don't call memoryPool.Free(pMemory);
		//memoryPool.Free(pMemory);
	}
	/**
	 * CZErrorProcessorBase::SetProcessError(NULL) can be removed if you want to use the same error processor in all the application.
	 */
	CZErrorProcessorBase::SetProcessError(NULL);
}

void CPropPageMemoryPool::OnBnClickedBtnDetectMemoryOverflow()
{
	// TODO: Add your control notification handler code here
	/*
	 * CZErrorProcessorBase::SetProcessError(CZErrorProcessorBase * p_pCZErrorProcessorBase) is not multi-thread safe.
	 * It is recommended to define CErrorProcessorMessageBox as a static variable and call CZErrorProcessorBase::SetProcessError(CZErrorProcessorBase * p_pCZErrorProcessorBase) only once when the application starts.
	 * We call CZErrorProcessorBase::SetProcessError(CZErrorProcessorBase * p_pCZErrorProcessorBase) here just for demonstration.
	 * In the following example, we added { and } to ensure the destructor of CZMemoryPool is called before calling CZErrorProcessorBase::SetProcessError(NULL).
	 */
	{
		CZErrorProcessorBase::SetProcessError(&errorProcessorMessageBox);
		CZMemoryPool memoryPool;
		
		//CZMemoryPool (or OS) will generate error when trying to free an invalid memory
		char szTest[10];
		char * pNonAllocated = szTest;
		memoryPool.Free(pNonAllocated);

		//CZMemoryPool will generate error when trying to free the same memory twice
		char * pFreeTwice = (char *)memoryPool.Malloc(4);
		memoryPool.Free(pFreeTwice);
		memoryPool.Free(pFreeTwice);

		//CZMemoryPool will generate error when there is memory overflow
		//The Windows system will also generate an error message for memory overflow
		char * pMemory = (char *)memoryPool.Malloc(4);
		strcpy(pMemory - 1, "overflow");
		memoryPool.Free(pMemory);
	}
	/**
	 * CZErrorProcessorBase::SetProcessError(NULL) can be removed if you want to use the same error processor in all the application.
	 */
	CZErrorProcessorBase::SetProcessError(NULL);
}
