/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#ifndef _ZTREE_MEMERY_POOL_RELEASER_H_
#define _ZTREE_MEMERY_POOL_RELEASER_H_

#include "ZMemeryReleaserBase.h"
#include "ZMemoryPool.h"

/**
 * 
 * CZMemeryReleaserPool - Release memory from CZMemoryPool by calling CZMemoryPool.Free(void * ).
 * 
 */

class CZMemeryReleaserPool : public CZMemeryReleaserBase
{
public:
	CZMemeryReleaserPool(void);
	virtual ~CZMemeryReleaserPool(void);
	
public:
	void				SetMemeryPool(CZMemoryPool * p_pMemeryPool);
	//The derived class must override this function to free/delete/delete [] the pointer. Please use CZMemeryReleaserNULL if there is no need to release memory.
	void 				Release(void * p_pPointer);
	
private:
	CZMemoryPool * 		m_pMemoryPool;
};

#endif