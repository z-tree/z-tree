/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#ifndef _ZTREE_BASE_H_
#define _ZTREE_BASE_H_

#include "ZCommon.h"
#include "ZMemeryReleaserBase.h"


#define ZTREE_VALUE_ARRAY_SIZE 4
#define	ZTREE_IS_BRANCH_NODE	0
#define ZTREE_BITS_NUMBER_PER_CHAR	8
//#define	BITS_NUMBER_PER_INT64	64

typedef struct struZTreeValue
{
	struct struZTreeValue * 	m_pNextZTreeValue;
	union {
		void *						m_pValues[ZTREE_VALUE_ARRAY_SIZE];
		Z_INT64					m_nValues[ZTREE_VALUE_ARRAY_SIZE];
	};
}ZTREE_VALUE;


typedef struct struZTreeValueHead
{
	ZTREE_VALUE m_ZTREE_VALUE;
	ZTREE_VALUE * m_pLastZTREE_VALUE;
}ZTREE_VALUE_HEAD;


typedef struct struZTreeBranchNodes
{
	//m_nFlag indicates if this is a ZTREE_BRANCH_NODE or ZTREE_KEY_NODE. If m_nFlag is 0, this is a ZTREE_BRANCH_NODE. Otherwise this is a ZTREE_KEY_NODE 
	int							m_nFlag;
	//m_pBranches[2] points to two children nodes. They may be ZTREE_BRANCH_NODE or ZTREE_KEY_NODE
	void *						m_pBranchNodes[2];
	//The value can be a ZTREE_VALUE Linked List or a simple integer
	union {
		ZTREE_VALUE_HEAD * 			m_pValueHead;
		void *						m_pValue;
		int							m_nValue;
	};
}ZTREE_BRANCH_NODE;

typedef struct struZTreeKeyNode
{
	//m_nBitLevelEnd should never be 0. If m_nBitLevelEnd is 0, m_nFlag takes effect. That means this node is a ZTREE_BRANCH_NODE.
	union {
		int							m_nFlag;
		unsigned int				m_nBitLevelEnd;
	};
	
	//Key buffer
	unsigned char			*	m_pKey;
	//Key bits start position and end pisition
	unsigned int				m_nBitLevelStart;
	//unsigned int				m_nBitLevelEnd;
	
	//m_pNextNode points to the next node. It may be ZTREE_BRANCH_NODE or ZTREE_KEY_NODE
	void *						m_pNextNode;
	//The value can be a ZTREE_VALUE Linked List or a simple integer
	union {
		ZTREE_VALUE_HEAD * 			m_pValueHead;
		void *						m_pValue;
		int							m_nValue;
	};
}ZTREE_KEY_NODE;

/**
 * CZTreeBase
 * 
 * CZTreeBase is the base class for Z-Tree.
 * CZTreeBase should not be used by your application. You application should use one of the following classes:
 *
 * CZTreeNoValue - CZTreeNoValue is similar to a set. When your application only uses keys and there is no value, CZTreeNoValue should be used.
 * For example, when you are sorting a file, you can use CZTreeNoValue. 
 * 
 * CZTreeOneValue - CZTreeOneValue is similar to a hash table. When your application is using key-value mapping and for each key there is only one value, CZTreeOneValue should be used.
 * For CZTreeOneValue, if you call AddKeyValue(...) twice for the same key, there should be only one value for the key.
 * For example, when you need to find a person's name by ID, you can use CZTreeNoValue.
 *
 * CZTreeValueList - CZTreeValueList  is similar to a multiple-value hash table. When your application is using key-value mapping and for each key there may be multiple values, CZTreeValueList should be used.
 * For CZTreeValueList, if you call AddKeyValue(...) twice for the same key, there should be two values for the key.
 * For example, a person may have multiple friends. when you need to find a person's friends by ID, you can use CZTreeValueList.
 * 
 */

class CZTreeBase
{
public:
	CZTreeBase(void);
	virtual ~CZTreeBase(void);

public:
	//Initialize Z-Tree. 
	virtual void				InitZTree();
	//Set Memory Releaser to release values
	virtual void				SetMemeryReleaser(CZMemeryReleaserBase * p_pMemeryReleaserBase);
	//Release Z-Tree
	virtual void				ReleaseZTree(BOOL p_bFreeValues);
	//Insert a node
	virtual BOOL				AddKeyValue(unsigned char * p_szKey, unsigned int p_nBufferLength, void * p_pValue);
	//Get root node to traverse
	virtual void	*			GetRootNode();
	//Find the head of the value by key
	virtual ZTREE_VALUE_HEAD  *	GetValue(unsigned char * p_szKey, Z_INT64 p_nBufferLength);
	//Remove a node
	virtual BOOL  				RemoveKeyValue(unsigned char * p_szKey, Z_INT64 p_nBufferLength, BOOL p_bFreeValues);
	//Set value to key
	BOOL						SetKeyValue(unsigned char * p_szKey, unsigned int p_nBufferLength, void * p_pValue, BOOL p_bFreeValues);
	//Get value number from ZTREE_VALUE
	static unsigned int			GetValueNumberFromZTREE_VALUE(ZTREE_VALUE * p_pZTREE_VALUE);
	//Get longest match bit number
	int					GetLongestCommonBitNumber(unsigned char * p_szKey, unsigned int p_nBufferLength);

public:
	static	unsigned char		m_uchBitsMask[ZTREE_BITS_NUMBER_PER_CHAR];
	
protected:
	ZTREE_BRANCH_NODE *			m_pZTreeNodeRoot;
	virtual void *				ZMalloc(size_t size);
	virtual void				ZFree(void* ptr);
	virtual ZTREE_BRANCH_NODE *	AllocBRANCH_NODE();
	virtual ZTREE_KEY_NODE *	AllocKEY_NODE(unsigned char * p_szKey, Z_INT64 p_nBufferLength);
	virtual void				ReleaseZTreeValue(void * p_pValue);
	virtual void				ReleaseZTreeValueHead(ZTREE_VALUE_HEAD * pZTreeValueHead, BOOL p_bFreeValues);
	virtual void				ReleaseZTreeNode(void * p_pNode, BOOL p_bFreeValues);
	virtual BOOL				AddValueToZTREE_NODE(void * p_pNode, void * p_pValue);
	virtual void * 				MoveValueListToTheSucceedingNode(ZTREE_VALUE_HEAD * p_pValueHead, void * p_pNodeSucceed);
	inline int					GetBit(unsigned char * p_szKey, unsigned int p_nBitLevelStart);
	unsigned int				GetNonMatchBitIndex(unsigned char * p_szKey1, unsigned char * p_szKey2, unsigned int p_nKey1BitStart, unsigned int p_nKey2BitStart, unsigned int p_nMaxBitNumber);
	virtual BOOL				AddKeyValue(void * p_pNode, unsigned char * p_szKey, unsigned int p_nBitLevelStart, unsigned int p_nBitLevelEnd, void * p_pValue);
	virtual ZTREE_VALUE_HEAD  *	GetValue(void * p_pNode, unsigned char * p_szKey, unsigned int p_nBitLevelStart, unsigned int p_nBitLevelEnd);
	virtual void				PrintZTreeNode(void * p_pNode, void * p_pExclude = NULL);
	int							GetLongestCommonBitNumber(void * p_pNode, unsigned char * p_szKey, unsigned int p_nBitLevelStart, unsigned int p_nBitLevelEnd);
	
	static const int			m_nStackDepth = 8;
	void *						m_pNodeStack[m_nStackDepth];
	int							m_nStackIndex;
	
	CZMemeryReleaserBase * 		m_pMemeryReleaserBase;

};

#endif