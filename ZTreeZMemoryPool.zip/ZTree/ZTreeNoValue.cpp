/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#include "ZMemoryPool.h"
#include "ZTreeNoValue.h"
#include "ZErrorProcessorBase.h"


CZTreeNoValue::CZTreeNoValue(void)
{
}

CZTreeNoValue::~CZTreeNoValue(void)
{
}

void * CZTreeNoValue::ZMalloc(size_t size)
{
	return m_memoryPool.Malloc(size);
}

void CZTreeNoValue::ZFree(void* ptr)
{
	m_memoryPool.Free(ptr);
}

void CZTreeNoValue::SetQuickMode(BOOL p_bQuickMode)
{
	m_memoryPool.SetQuickMode(TRUE);
}

void	CZTreeNoValue::ReleaseZTreeValueHead(ZTREE_VALUE_HEAD * pZTreeValueHead, BOOL p_bFreeValues)
{
	//No need to release anything
}

/**
 * Increment p_pNode->m_nValue
 * Return TRUE
 */
BOOL CZTreeNoValue::AddValueToZTREE_NODE(void * p_pNode, void * p_pValue)
{
	ZTREE_VALUE_HEAD * pZTREE_VALUE_HEAD = NULL;
	ZTREE_VALUE * pListTail = NULL;
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		((ZTREE_BRANCH_NODE *)p_pNode)->m_nValue++;
	}
	else
	{
		((ZTREE_KEY_NODE *)p_pNode)->m_nValue++;
	}

	return TRUE;
}

int	CZTreeNoValue::GetKeyCounter(unsigned char * p_szKey, Z_INT64 p_nBufferLength)
{
	memset(m_pNodeStack, 0X00, sizeof(void *) * m_nStackDepth);
	m_nStackIndex = 0;
	if(m_pZTreeNodeRoot == NULL)
	{
		return 0;
	}
	return (int)GetValue(m_pZTreeNodeRoot, p_szKey, 0, (unsigned int)p_nBufferLength * ZTREE_BITS_NUMBER_PER_CHAR);
}

