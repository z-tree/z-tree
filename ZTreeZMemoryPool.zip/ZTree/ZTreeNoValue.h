/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#ifndef _ZTREE_NO_VALUE_H_
#define _ZTREE_NO_VALUE_H_

#include "ZCommon.h"
#include "ZMemeryReleaserBase.h"
#include "ZMemeryReleaserPool.h"
#include "ZTreeBase.h"


/**
 * CZTreeNoValue
 * 
 * CZTreeBase is the base class for Z-Tree.
 * CZTreeBase should not be used by your application. You application should use one of the following classes:
 *
 * CZTreeNoValue - CZTreeNoValue is similar to a set. When your application only uses keys and there is no value, CZTreeNoValue should be used.
 * For example, when you are sorting a file, you can use CZTreeNoValue. 
 * 
 * CZTreeOneValue - CZTreeOneValue is similar to a hash table. When your application is using key-value mapping and for each key there is only one value, CZTreeOneValue should be used.
 * For CZTreeOneValue, if you call AddKeyValue(...) twice for the same key, there should be only one value for the key.
 * For example, when you need to find a person's name by ID, you can use CZTreeNoValue.
 *
 * CZTreeValueList - CZTreeValueList  is similar to a multiple-value hash table. When your application is using key-value mapping and for each key there may be multiple values, CZTreeValueList should be used.
 * For CZTreeValueList, if you call AddKeyValue(...) twice for the same key, there should be two values for the key.
 * For example, a person may have multiple friends. when you need to find a person's friends by ID, you can use CZTreeValueList.
 * 
 */

class CZTreeNoValue : public CZTreeBase
{
public:
	CZTreeNoValue(void);
	virtual ~CZTreeNoValue(void);

public:
	void					SetQuickMode(BOOL p_bQuickMode);
	virtual int				GetKeyCounter(unsigned char * p_szKey, Z_INT64 p_nBufferLength);
	
protected:
	CZMemoryPool			m_memoryPool;
	void *					ZMalloc(size_t size);
	void					ZFree(void* ptr);
	void					ReleaseZTreeValueHead(ZTREE_VALUE_HEAD * pZTreeValueHead, BOOL p_bFreeValues);
	BOOL					AddValueToZTREE_NODE(void * p_pNode, void * p_pValue);
};

#endif