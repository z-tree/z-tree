/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#ifndef _ZTREE_ERROR_PROCESSOR_BASE_H_
#define _ZTREE_ERROR_PROCESSOR_BASE_H_

#include "ZCommon.h"

/**
 * CZErrorProcessorBase
 * 
 * CZErrorProcessorBase is the base class for Z-Tree and Z-Memory Pool error handling. 
 * To show the errors in message box or write the errors into log files, you need to redefine the error handling class.
 * 1. Create a child error handling class based on CZErrorProcessorBase. For example:
 *         class CErrorProcessorMessageBox : public CZErrorProcessorBase
 * 
 * 2. Redefine function "void ProcessErrorMsg(const char * p_pPointer)". For example:
 *         void CErrorProcessorMessageBox::ProcessErrorMsg(const char * p_pPointer)
 *         {
 *             TCHAR 	wszTempBuffer[1000];
 *             int nLength = MultiByteToWideChar(CP_UTF8, 0, p_pPointer, (int)strlen(p_pPointer), wszTempBuffer, 1000 - 1);
 *             wszTempBuffer[nLength] = 0X00;
 *             AfxMessageBox(wszTempBuffer);
 *         }
 * 
 * 3. Create a global or static object for the child error handling class. For example:
 *         static CErrorProcessorMessageBox	m_errorProcessorMessageBox;
 * 
 * 4. Assign the error handling object to CZErrorProcessorBase when application startes. For example:
 *         CZErrorProcessorBase::SetProcessError(&m_errorProcessorMessageBox);
 * 
 */

class CZErrorProcessorBase
{
public:
	CZErrorProcessorBase(void);
	virtual ~CZErrorProcessorBase(void);
	
public:
	virtual void					ProcessErrorMsg(const char * p_pPointer) = 0;
	static CZErrorProcessorBase *	GetProcessError();
	static void						SetProcessError(CZErrorProcessorBase * p_pCZErrorProcessorBase);
	static void						ProcessError(const char * p_pPointer);

private:	
	static CZErrorProcessorBase	*	m_pCZErrorProcessorBase;
};

#endif
