/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#include "ZMemoryZTree.h"
#include "ZMemoryPool.h"
#include "ZErrorProcessorBase.h"


CZMemoryZTree::CZMemoryZTree(void)
{
}

CZMemoryZTree::~CZMemoryZTree(void)
{
}

//Functions to check un-freeed memory (Not memory leak)
BOOL	CZMemoryZTree::CheckMemoryLeakInValues(ZTREE_VALUE_HEAD * pZTreeValueHead)
{
	if(pZTreeValueHead != NULL)
	{
		MEMORY_POOL_BLOCK_HEAD * pPoolHead = (MEMORY_POOL_BLOCK_HEAD *)pZTreeValueHead;
		if((pPoolHead->m_nBlockFlag != CZMemoryPool::THRESHOLD_COUNT_BLOCK_SMALL
				&& pPoolHead->m_nBlockFlag != CZMemoryPool::THRESHOLD_COUNT_BLOCK_MEDIUM
				&& pPoolHead->m_nBlockFlag != CZMemoryPool::THRESHOLD_COUNT_BLOCK_HUGE
				&& pPoolHead->m_nBlockFlag != CZMemoryPool::THRESHOLD_COUNT_BLOCK_GIGANTIC)
			|| pPoolHead->m_nBitmapEmpty != CZMemoryPool::BLOCK_IS_EMPTY)
		{
			//If this pool is not empty, show error message
			CZErrorProcessorBase::ProcessError("Memory Pool: Found un-freeed memory. This will not cause memory leak but it is still recommended to call Free() or DeleteObject() to free them.");
		}
		return FALSE;
	}
	return TRUE;
}

BOOL CZMemoryZTree::CheckMemoryLeakInNode(void * p_pNode)
{
	if(p_pNode == NULL)
	{
		return TRUE;
	}
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0] != NULL)
		{
			if(!CheckMemoryLeakInNode(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0]))
			{
				return FALSE;
			}
		}
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1] != NULL)
		{
			if(!CheckMemoryLeakInNode(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1]))
			{
				return FALSE;
			}
		}
		
		//Check System Memory or Memory Pool Block. Here m_pValueHead is the same as m_pValue.
		ZTREE_VALUE_HEAD * pCurNodeHead = ((ZTREE_BRANCH_NODE *)p_pNode)->m_pValueHead;
		if(!CheckMemoryLeakInValues(pCurNodeHead))
		{
			return FALSE;
		}
	}
	else
	{
		if(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode != NULL)
		{
			if(!CheckMemoryLeakInNode(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode))
			{
				return FALSE;
			}
		}
		
		//Check System Memory or Memory Pool Block. Here m_pValueHead is the same as m_pValue.
		ZTREE_VALUE_HEAD * pCurNodeHead = ((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead;
		if(!CheckMemoryLeakInValues(pCurNodeHead))
		{
			return FALSE;
		}
	}
	return TRUE;
}

BOOL	CZMemoryZTree::CheckMemoryLeak()
{
	return CheckMemoryLeakInNode(m_pZTreeNodeRoot);
}
