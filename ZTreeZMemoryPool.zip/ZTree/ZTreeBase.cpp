/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#include "ZTreeBase.h"
#include "ZMemoryPool.h"
#include "ZErrorProcessorBase.h"


unsigned char	CZTreeBase::m_uchBitsMask[ZTREE_BITS_NUMBER_PER_CHAR] = {0X80, 0X40, 0X20, 0X10, 0X08, 0X04, 0X02, 0X01};

CZTreeBase::CZTreeBase(void)
{
	m_pMemeryReleaserBase = NULL;
	m_pZTreeNodeRoot = NULL;
	//We should not call InitZTree() here because ZMalloc will call free() instead od ZMemoryPool.Free() due to the child class has not been created.
}

CZTreeBase::~CZTreeBase(void)
{
	//We should not call ReleaseZTree(FALSE) here as it is not sure if ZMalloc will call free() or ZMemoryPool.Free() due to maybe the child class has already been destroyed.
}

void * CZTreeBase::ZMalloc(size_t size)
{
	return malloc(size);
}

void CZTreeBase::ZFree(void* ptr)
{
	free(ptr);
}

//New Tree
ZTREE_BRANCH_NODE *	CZTreeBase::AllocBRANCH_NODE()
{
	ZTREE_BRANCH_NODE * pADNodeNew = (ZTREE_BRANCH_NODE *)ZMalloc(sizeof(ZTREE_BRANCH_NODE));
	memset(pADNodeNew, 0, sizeof(ZTREE_BRANCH_NODE));
	return pADNodeNew;
}

ZTREE_KEY_NODE *		CZTreeBase::AllocKEY_NODE(unsigned char * p_szKey, Z_INT64 p_nBufferLength)
{
	ZTREE_KEY_NODE * pADNodeNew = (ZTREE_KEY_NODE *)ZMalloc(sizeof(ZTREE_KEY_NODE) + (size_t)p_nBufferLength);
	memset(pADNodeNew, 0, sizeof(ZTREE_KEY_NODE));
	memcpy(((unsigned char *)pADNodeNew) + sizeof(ZTREE_KEY_NODE), p_szKey, (size_t)p_nBufferLength);
	return pADNodeNew;
}

void	CZTreeBase::InitZTree()
{
	if(m_pZTreeNodeRoot != NULL)
	{
		CZErrorProcessorBase::ProcessError("CZTreeBase alredy initialized.");
		return;
	}
	m_pZTreeNodeRoot = AllocBRANCH_NODE();
}

void	CZTreeBase::SetMemeryReleaser(CZMemeryReleaserBase * p_pMemeryReleaserBase)
{
	m_pMemeryReleaserBase = p_pMemeryReleaserBase;
}

void	CZTreeBase::ReleaseZTreeValue(void * p_pValue)
{
	if(m_pMemeryReleaserBase != NULL)
	{
		m_pMemeryReleaserBase->Release(p_pValue);
	}
}

void	CZTreeBase::ReleaseZTreeValueHead(ZTREE_VALUE_HEAD * pZTreeValueHead, BOOL p_bFreeValues)
{
	if(pZTreeValueHead != NULL && p_bFreeValues)
	{
		ReleaseZTreeValue(pZTreeValueHead);
	}	
}

void CZTreeBase::ReleaseZTreeNode(void * p_pNode, BOOL p_bFreeValues)
{
	if(p_pNode == NULL)
	{
		return;
	}
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0] != NULL)
		{
			ReleaseZTreeNode(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0], p_bFreeValues);
		}
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1] != NULL)
		{
			ReleaseZTreeNode(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1], p_bFreeValues);
		}
		
		//Free index list
		ZTREE_VALUE_HEAD * pCurNodeHead = ((ZTREE_BRANCH_NODE *)p_pNode)->m_pValueHead;
		ReleaseZTreeValueHead(pCurNodeHead, p_bFreeValues);
	}
	else
	{
		if(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode != NULL)
		{
			ReleaseZTreeNode(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode, p_bFreeValues);
		}
		
		//Free index list
		ZTREE_VALUE_HEAD * pCurNodeHead = ((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead;
		ReleaseZTreeValueHead(pCurNodeHead, p_bFreeValues);
	}
	ZFree(p_pNode);
}

void	CZTreeBase::ReleaseZTree(BOOL p_bFreeValues)
{
	ReleaseZTreeNode(m_pZTreeNodeRoot, p_bFreeValues);
	m_pZTreeNodeRoot = NULL;
}


/**
 * Simply append the index to the last node of p_pADNode->m_pFirstIndex
 * Return TRUE if this is the only value, else return FALSE
 */
BOOL CZTreeBase::AddValueToZTREE_NODE(void * p_pNode, void * p_pValue)
{
	ZTREE_VALUE_HEAD * pZTREE_VALUE_HEAD = NULL;
	ZTREE_VALUE * pListTail = NULL;
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		//Here m_pValue is the same as m_pValueHead
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pValueHead != NULL)
		{
			ReleaseZTreeValue(((ZTREE_BRANCH_NODE *)p_pNode)->m_pValue);
		}
		((ZTREE_BRANCH_NODE *)p_pNode)->m_pValue = p_pValue;
	}
	else
	{
		//Here m_pValue is the same as m_pValueHead
		if(((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead == NULL)
		{
			ReleaseZTreeValue(((ZTREE_KEY_NODE *)p_pNode)->m_pValue);
		}
		((ZTREE_KEY_NODE *)p_pNode)->m_pValue = p_pValue;
	}

	return TRUE;
}

//return 0 if the corresponding bit is 0, otherwise return 1
int		CZTreeBase::GetBit(unsigned char * p_szKey, unsigned int p_nBitLevelStart)
{
	if(p_szKey[p_nBitLevelStart / ZTREE_BITS_NUMBER_PER_CHAR] & m_uchBitsMask[p_nBitLevelStart - p_nBitLevelStart / ZTREE_BITS_NUMBER_PER_CHAR * ZTREE_BITS_NUMBER_PER_CHAR])
	{
		return 1;
	}
	return 0;
}

//This function will move index list (p_pValueHead) of a 0 bit node to the next ZTREE_BRANCH_NODE
void * CZTreeBase::MoveValueListToTheSucceedingNode(ZTREE_VALUE_HEAD * p_pValueHead, void * p_pNodeSucceed)
{
	if(p_pValueHead == NULL)
	{
		return p_pNodeSucceed;
	}
	if(p_pNodeSucceed == NULL)
	{
		ZTREE_BRANCH_NODE * pBRANCH_NODE = AllocBRANCH_NODE();
		pBRANCH_NODE->m_pValueHead = p_pValueHead;
		return pBRANCH_NODE;
	}
	if(((ZTREE_BRANCH_NODE *)p_pNodeSucceed)->m_nFlag == ZTREE_IS_BRANCH_NODE) //The next node is ZTREE_BRANCH_NODE
	{
		if(((ZTREE_BRANCH_NODE *)p_pNodeSucceed)->m_pValueHead != NULL)
		{
			CZErrorProcessorBase::ProcessError("((ZTREE_BRANCH_NODE *)p_pNodeSucceed)->m_pValueHead != NULL");
		}
		((ZTREE_BRANCH_NODE *)p_pNodeSucceed)->m_pValueHead = p_pValueHead;
		return p_pNodeSucceed;
	}
	else
	{
		//If p_pNodeSucceed has only one bit, change it into ZTREE_BRANCH_NODE
		if(((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_nBitLevelStart == 1)
		{
			int nBitFromTree = GetBit(((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_pKey, ((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_nBitLevelStart);
			ZTREE_VALUE_HEAD * pChildIndexList = ((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_pValueHead;
			void * pChildNode = ((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_pNextNode;
			
			//Change ZTREE_KEY_NODE to ZTREE_BRANCH_NODE
			memset(p_pNodeSucceed, 0, sizeof(ZTREE_BRANCH_NODE));
			((ZTREE_BRANCH_NODE *)p_pNodeSucceed)->m_pValueHead = p_pValueHead;
			((ZTREE_BRANCH_NODE *)p_pNodeSucceed)->m_pBranchNodes[nBitFromTree] = MoveValueListToTheSucceedingNode(pChildIndexList, pChildNode);
			return p_pNodeSucceed;
		}
		else //If p_pNodeSucceed has more than 2 bits, split it.
		{
			ZTREE_BRANCH_NODE *	pBRANCH_NODE = AllocBRANCH_NODE();
			pBRANCH_NODE->m_pValueHead = p_pValueHead;
			
			//Append p_pNodeSucceed to pBRANCH_NODE
			int nBitFromTree = GetBit(((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_pKey, ((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_nBitLevelStart);
			((ZTREE_KEY_NODE *)p_pNodeSucceed)->m_nBitLevelStart++;
			pBRANCH_NODE->m_pBranchNodes[nBitFromTree] = p_pNodeSucceed;
			return pBRANCH_NODE;
		}
	}
}

unsigned int CZTreeBase::GetNonMatchBitIndex(unsigned char * p_szKey1, unsigned char * p_szKey2, unsigned int p_nKey1BitStart, unsigned int p_nKey2BitStart, unsigned int p_nMaxBitNumber)
{
	//If there are less than 2 bytes, check the bits one by one
	if(p_nMaxBitNumber < ZTREE_BITS_NUMBER_PER_CHAR * 2)
	{
		for(unsigned int nBitIndex = 0; nBitIndex < p_nMaxBitNumber; nBitIndex++)
		{
			char char1 = p_szKey1[(p_nKey1BitStart + nBitIndex) / ZTREE_BITS_NUMBER_PER_CHAR];
			char char2 = p_szKey2[(p_nKey2BitStart + nBitIndex) / ZTREE_BITS_NUMBER_PER_CHAR];
			if((char1 & m_uchBitsMask[(p_nKey1BitStart + nBitIndex) % ZTREE_BITS_NUMBER_PER_CHAR]) != (char2 & m_uchBitsMask[(p_nKey2BitStart + nBitIndex) % ZTREE_BITS_NUMBER_PER_CHAR]))
			{
				return nBitIndex;
			}
		}
		return p_nMaxBitNumber;
	}
	else
	{
		//Check the unmatch bit in the first half char
		char char1 = p_szKey1[p_nKey1BitStart/ ZTREE_BITS_NUMBER_PER_CHAR];
		char char2 = p_szKey2[p_nKey2BitStart / ZTREE_BITS_NUMBER_PER_CHAR];
		unsigned int nFirstHalfCharBitNum = (p_nKey1BitStart + ZTREE_BITS_NUMBER_PER_CHAR - 1) / ZTREE_BITS_NUMBER_PER_CHAR * ZTREE_BITS_NUMBER_PER_CHAR - p_nKey1BitStart;
		for(unsigned int nBitIndex = 0; nBitIndex < nFirstHalfCharBitNum; nBitIndex++)
		{
			if((char1 & m_uchBitsMask[(p_nKey1BitStart + nBitIndex) % ZTREE_BITS_NUMBER_PER_CHAR]) != (char2 & m_uchBitsMask[(p_nKey2BitStart + nBitIndex) % ZTREE_BITS_NUMBER_PER_CHAR]))
			{
				return nBitIndex;
			}
		}
		
		//Check the unmatch bit in the middle full char
		unsigned int nFullCharNum = (p_nMaxBitNumber - nFirstHalfCharBitNum) / ZTREE_BITS_NUMBER_PER_CHAR;
		unsigned int nKey1StartCharIndex = (p_nKey1BitStart + ZTREE_BITS_NUMBER_PER_CHAR - 1) / ZTREE_BITS_NUMBER_PER_CHAR;
		unsigned int nKey2StartCharIndex = (p_nKey2BitStart + ZTREE_BITS_NUMBER_PER_CHAR - 1) / ZTREE_BITS_NUMBER_PER_CHAR;
		for(unsigned int nCharIndex = 0; nCharIndex < nFullCharNum; nCharIndex++)
		{
			if(p_szKey1[nKey1StartCharIndex + nCharIndex] != p_szKey2[nKey2StartCharIndex + nCharIndex])
			{
				char char1 = p_szKey1[nKey1StartCharIndex + nCharIndex];
				char char2 = p_szKey2[nKey2StartCharIndex + nCharIndex];
				for(unsigned int nBitIndex = 0; nBitIndex < ZTREE_BITS_NUMBER_PER_CHAR; nBitIndex++)
				{
					if((char1 & m_uchBitsMask[nBitIndex]) != (char2 & m_uchBitsMask[nBitIndex]))
					{
						return nFirstHalfCharBitNum + nCharIndex * ZTREE_BITS_NUMBER_PER_CHAR + nBitIndex;
					}
				}
				CZErrorProcessorBase::ProcessError("should not reach here!");
			}
		}
		
		//Check the unmatch bit in the end half char
		unsigned int nLastHalfCharBitNum = (p_nKey1BitStart + p_nMaxBitNumber) - (p_nKey1BitStart + p_nMaxBitNumber) / ZTREE_BITS_NUMBER_PER_CHAR * ZTREE_BITS_NUMBER_PER_CHAR;
		if(nLastHalfCharBitNum > 0)
		{
			char1 = p_szKey1[(p_nKey1BitStart + p_nMaxBitNumber) / ZTREE_BITS_NUMBER_PER_CHAR];
			char2 = p_szKey2[(p_nKey2BitStart + p_nMaxBitNumber) / ZTREE_BITS_NUMBER_PER_CHAR];
			for(unsigned int nBitIndex = 0; nBitIndex < nLastHalfCharBitNum; nBitIndex++)
			{
				if((char1 & m_uchBitsMask[nBitIndex]) != (char2 & m_uchBitsMask[nBitIndex]))
				{
					return nFirstHalfCharBitNum + nFullCharNum * ZTREE_BITS_NUMBER_PER_CHAR + nBitIndex;
				}
			}
		}
		
		return p_nMaxBitNumber;
	}
}

//Insert a Key (p_szKey) and value p_pValue into p_pNode
BOOL	CZTreeBase::AddKeyValue(void * p_pNode, unsigned char * p_szKey, unsigned int p_nBitLevelStart, unsigned int p_nBitLevelEnd, void * p_pValue)
{
	void * 	pParentNode = p_pNode;
	int		nParentBranchIndex = -1;
	while(TRUE)
	{
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
		{
			if(p_nBitLevelStart == p_nBitLevelEnd)
			{
				return AddValueToZTREE_NODE(p_pNode, p_pValue);
			}
			int nBranchIndex = GetBit(p_szKey, p_nBitLevelStart);
			if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] == NULL)
			{
				if(p_nBitLevelStart + 1 == p_nBitLevelEnd)
				{
					//Add this index to a ZTREE_BRANCH_NODE
					ZTREE_BRANCH_NODE * pBRANCH_NODE = AllocBRANCH_NODE();

					((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] = pBRANCH_NODE;
					return AddValueToZTREE_NODE(pBRANCH_NODE, p_pValue);
				}
				else
				{
					//Add this index to a ZTREE_KEY_NODE
					ZTREE_KEY_NODE * pKEY_NODE = AllocKEY_NODE(p_szKey + (p_nBitLevelStart + 1) / ZTREE_BITS_NUMBER_PER_CHAR, (p_nBitLevelEnd + ZTREE_BITS_NUMBER_PER_CHAR - 1) / ZTREE_BITS_NUMBER_PER_CHAR - (p_nBitLevelStart + 1) / ZTREE_BITS_NUMBER_PER_CHAR);
					pKEY_NODE->m_pKey = ((unsigned char *)pKEY_NODE) + sizeof(ZTREE_KEY_NODE);
					pKEY_NODE->m_nBitLevelStart = (p_nBitLevelStart + 1) - (p_nBitLevelStart + 1) / ZTREE_BITS_NUMBER_PER_CHAR * ZTREE_BITS_NUMBER_PER_CHAR;
					pKEY_NODE->m_nBitLevelEnd = p_nBitLevelEnd - (p_nBitLevelStart + 1) / ZTREE_BITS_NUMBER_PER_CHAR * ZTREE_BITS_NUMBER_PER_CHAR;

					((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] = pKEY_NODE;
					return AddValueToZTREE_NODE(pKEY_NODE, p_pValue);
				}
			}//if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] == NULL)
			else
			{
				pParentNode = p_pNode;
				nParentBranchIndex = nBranchIndex;
				
				p_nBitLevelStart++;
				p_pNode = ((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex];
				continue;
			}
		}//if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
		else //p_pNode is a ZTREE_KEY_NODE. Split this ZTREE_KEY_NODE
		{
			//find the first different bit index
			unsigned int nMaxBitNumber = ((p_nBitLevelEnd - p_nBitLevelStart) <= (unsigned int)(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart) ? (p_nBitLevelEnd - p_nBitLevelStart) : (unsigned int)(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart));
			unsigned int nNonMatchBitIndex = GetNonMatchBitIndex(p_szKey, ((ZTREE_KEY_NODE *)p_pNode)->m_pKey, p_nBitLevelStart, ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart, nMaxBitNumber);
			unsigned int nSplitBitIndex = p_nBitLevelStart + nNonMatchBitIndex;
			
			void * pNodeFromParam = NULL;
			void * pNodeFromTree = NULL;
			
			//Split tree node key
			//Tree node matches completely, no need to split
			if(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart) == ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd)
			{
			}
			//Differs in the last bit
			else if(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart) == ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - 1)
			{
				unsigned int nBitFromTree = GetBit(((ZTREE_KEY_NODE *)p_pNode)->m_pKey, ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart));
				//If there is only one bit
				if(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart == ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - 1)
				{
					void * pNextNode = MoveValueListToTheSucceedingNode(((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead, ((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode);
					
					//Tranform p_pNode to a ZTREE_BRANCH_NODE
					memset(p_pNode, 0, sizeof(ZTREE_BRANCH_NODE));
					((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBitFromTree] = pNextNode;
				}
				else
				{
					//Create a tail branch node
					ZTREE_BRANCH_NODE *	pBRANCH_NODE = AllocBRANCH_NODE();
					void * pNextNode = MoveValueListToTheSucceedingNode(((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead, ((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode);
					pBRANCH_NODE->m_pBranchNodes[nBitFromTree] = pNextNode;
					
					//Append pBRANCH_NODE to p_pNode and adjust head p_pNode
					((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode = pBRANCH_NODE;
					((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd--;
					((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead = NULL;
				}
			}
			//Differs in the first bit. The possibility that this node has only one bit has been processed in the previous else if. 
			//In this else if, the node should has at least 2 bits
			else if(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart) == ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart)
			{
				unsigned int nBitFromTree = GetBit(((ZTREE_KEY_NODE *)p_pNode)->m_pKey, ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart));
				//Create a head ZTREE_BRANCH_NODE
				ZTREE_BRANCH_NODE *	pBRANCH_NODE = AllocBRANCH_NODE();
				
				//Adjust p_pNode
				((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart++;
				
				//Insert pBRANCH_NODE between pParentNode and p_pNode
				if(nParentBranchIndex < 0)
				{
					((ZTREE_KEY_NODE *)pParentNode)->m_pNextNode = pBRANCH_NODE;
				}
				else
				{
					((ZTREE_BRANCH_NODE *)pParentNode)->m_pBranchNodes[nParentBranchIndex] = pBRANCH_NODE;
				}
				pBRANCH_NODE->m_pBranchNodes[nBitFromTree] = p_pNode;
				
				//Reassign p_pNode
				p_pNode = pBRANCH_NODE;
			}
			//Differs in a middle bit. We need to split it into 3 nodes
			else
			{
				unsigned int nBitFromTree = GetBit(((ZTREE_KEY_NODE *)p_pNode)->m_pKey, ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart));
				//Create a head ZTREE_KEY_NODE and a middle ZTREE_BRANCH_NODE. 
				ZTREE_KEY_NODE * pKEY_NODE = CZTreeBase::AllocKEY_NODE(p_szKey, 0);
				memcpy(pKEY_NODE, p_pNode, sizeof(ZTREE_KEY_NODE));
				
				//Adjust ((ZTREE_KEY_NODE *)p_pNode)
				((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd = ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart);
				((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead = NULL;
				
				//Create a middle ZTREE_BRANCH_NODE
				ZTREE_BRANCH_NODE *	pBRANCH_NODE = AllocBRANCH_NODE();
				
				//Adjust ((ZTREE_KEY_NODE *)pKEY_NODE)
				((ZTREE_KEY_NODE *)pKEY_NODE)->m_nBitLevelStart = ((ZTREE_KEY_NODE *)pKEY_NODE)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart) + 1;
				
				//Insert pBRANCH_NODE between p_pNode and pKEY_NODE
				((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode = pBRANCH_NODE;
				pBRANCH_NODE->m_pBranchNodes[nBitFromTree] = pKEY_NODE;
			}
			
			//Check the splitted nodes
			if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
			{
				continue;
			}
			else
			{
				if(p_nBitLevelStart + (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart) == p_nBitLevelEnd)
				{
					return AddValueToZTREE_NODE(p_pNode, p_pValue);
				}

				if(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode == NULL)
				{
					//Allocate a new ZTREE_KEY_NODE
					p_nBitLevelStart += (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart);
					ZTREE_KEY_NODE * pKEY_NODE = AllocKEY_NODE(p_szKey + p_nBitLevelStart / ZTREE_BITS_NUMBER_PER_CHAR, (p_nBitLevelEnd + ZTREE_BITS_NUMBER_PER_CHAR - 1) / ZTREE_BITS_NUMBER_PER_CHAR - p_nBitLevelStart / ZTREE_BITS_NUMBER_PER_CHAR);
					pKEY_NODE->m_pKey = ((unsigned char *)pKEY_NODE) + sizeof(ZTREE_KEY_NODE);
					pKEY_NODE->m_nBitLevelStart = p_nBitLevelStart - p_nBitLevelStart / ZTREE_BITS_NUMBER_PER_CHAR * ZTREE_BITS_NUMBER_PER_CHAR;
					pKEY_NODE->m_nBitLevelEnd = p_nBitLevelEnd - p_nBitLevelStart / ZTREE_BITS_NUMBER_PER_CHAR * ZTREE_BITS_NUMBER_PER_CHAR;
					
					((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode = pKEY_NODE;

					return AddValueToZTREE_NODE(pKEY_NODE, p_pValue);
				}
				
				pParentNode = p_pNode;
				nParentBranchIndex = -1;
				
				p_nBitLevelStart += (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart);
				p_pNode = ((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode;
				continue;
			}
		} //p_pNode is a ZTREE_KEY_NODE. Split this ZTREE_KEY_NODE
	}//while(TRUE)
	return TRUE;
}


BOOL	CZTreeBase::AddKeyValue(unsigned char * p_szKey, unsigned int p_nBufferLength, void * p_pValue)
{
	if(m_pZTreeNodeRoot == NULL)
	{
		CZErrorProcessorBase::ProcessError("m_pZTreeNodeRoot is NULL! Please call InitZTree() to initialize Z-Tree before adding keys/values.");
	}
	return AddKeyValue(m_pZTreeNodeRoot, p_szKey, 0, p_nBufferLength * ZTREE_BITS_NUMBER_PER_CHAR, p_pValue);
}

void	*	CZTreeBase::GetRootNode()
{
	return m_pZTreeNodeRoot;
}

ZTREE_VALUE_HEAD  *	CZTreeBase::GetValue(void * p_pNode, unsigned char * p_szKey, unsigned int p_nBitLevelStart, unsigned int p_nBitLevelEnd)
{
	void * 	pParentNode = p_pNode;
	int		nParentBranchIndex = -1;
	while(TRUE)
	{
		//Stack
		m_pNodeStack[m_nStackIndex] = p_pNode;
		m_nStackIndex = (m_nStackIndex + 1) % m_nStackDepth;

		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
		{
			if(p_nBitLevelStart == p_nBitLevelEnd)
			{
				return ((ZTREE_BRANCH_NODE *)p_pNode)->m_pValueHead;
			}
			int nBranchIndex = GetBit(p_szKey, p_nBitLevelStart);
			if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] == NULL)
			{
				return NULL;
			}//if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] == NULL)
			else
			{
				pParentNode = p_pNode;
				nParentBranchIndex = nBranchIndex;
				
				p_nBitLevelStart++;
				p_pNode = ((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex];
				continue;
			}
		}//if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
		else //p_pNode is a ZTREE_KEY_NODE. Split this ZTREE_KEY_NODE
		{
			//find the first different bit index
			unsigned int nMaxBitNumber = ((p_nBitLevelEnd - p_nBitLevelStart) <= (unsigned int)(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart) ? (p_nBitLevelEnd - p_nBitLevelStart) : (unsigned int)(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart));
			unsigned int nNonMatchBitIndex = GetNonMatchBitIndex(p_szKey, ((ZTREE_KEY_NODE *)p_pNode)->m_pKey, p_nBitLevelStart, ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart, nMaxBitNumber);
			unsigned int nSplitBitIndex = p_nBitLevelStart + nNonMatchBitIndex;
			
			void * pNodeFromParam = NULL;
			void * pNodeFromTree = NULL;
			
			//Split tree node key
			//Tree node matches completely, no need to split
			if(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart) == ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd)
			{
			}
			//Differs in the last bit
			else if(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart) == ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - 1)
			{
				return NULL;
			}
			//Differs in the first bit. The possibility that this node has only one bit has been processed in the previous else if. 
			//In this else if, the node should has at least 2 bits
			else if(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart + (nSplitBitIndex - p_nBitLevelStart) == ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart)
			{
				return NULL;
			}
			//Differs in a middle bit. We need to split it into 3 nodes
			else
			{
				return NULL;
			}
			
			//Check the splitted nodes
			if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
			{
				continue;
			}
			else
			{
				if(p_nBitLevelStart + (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart) == p_nBitLevelEnd)
				{
					return ((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead;
				}

				if(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode == NULL)
				{
					return NULL;
				}
				
				pParentNode = p_pNode;
				nParentBranchIndex = -1;
				
				p_nBitLevelStart += (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart);
				p_pNode = ((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode;
				continue;
			}
		} //p_pNode is a ZTREE_KEY_NODE. Split this ZTREE_KEY_NODE
	}//while(TRUE)
	return NULL;
}

ZTREE_VALUE_HEAD  *	CZTreeBase::GetValue(unsigned char * p_szKey, Z_INT64 p_nBufferLength)
{
	memset(m_pNodeStack, 0X00, sizeof(void *) * m_nStackDepth);
	m_nStackIndex = 0;
	return GetValue(m_pZTreeNodeRoot, p_szKey, 0, (unsigned int)p_nBufferLength * ZTREE_BITS_NUMBER_PER_CHAR);
}

//This function is for debug.
void CZTreeBase::PrintZTreeNode(void * p_pNode, void * p_pExclude)
{
	if(p_pNode == NULL || p_pNode == p_pExclude)
	{
		return;
	}
	if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
	{
		//TRACE("Brach Node: %08x--> [%08x, %08x]\n", p_pNode, ((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0], ((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1]);
		//Print index list
		ZTREE_VALUE_HEAD * pCurNodeHead = ((ZTREE_BRANCH_NODE *)p_pNode)->m_pValueHead;
		if(pCurNodeHead != NULL)
		{
			//TRACE("Node Value: %08x, %08x, %08x, %08x\n", pCurNodeHead->m_ZTREE_VALUE.m_pValues[0], pCurNodeHead->m_ZTREE_VALUE.m_pValues[1], pCurNodeHead->m_ZTREE_VALUE.m_pValues[2], pCurNodeHead->m_ZTREE_VALUE.m_pValues[3]);
		}

		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0] != NULL)
		{
			PrintZTreeNode(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[0]);
		}
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1] != NULL)
		{
			PrintZTreeNode(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[1]);
		}
	}
	else
	{
		//TRACE("Key Node: %08x--> [%08x]\n", p_pNode, ((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode);
		//Print index list
		ZTREE_VALUE_HEAD * pCurNodeHead = ((ZTREE_KEY_NODE *)p_pNode)->m_pValueHead;
		if(pCurNodeHead != NULL)
		{
			//TRACE("Node Value: %08x, %08x, %08x, %08x\n", pCurNodeHead->m_ZTREE_VALUE.m_pValues[0], pCurNodeHead->m_ZTREE_VALUE.m_pValues[1], pCurNodeHead->m_ZTREE_VALUE.m_pValues[2], pCurNodeHead->m_ZTREE_VALUE.m_pValues[3]);
		}

		if(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode != NULL)
		{
			PrintZTreeNode(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode);
		}
	}
}

unsigned int CZTreeBase::GetValueNumberFromZTREE_VALUE(ZTREE_VALUE * p_pZTREE_VALUE)
{
	unsigned int nReturn = 0;
	for(int i = 0; i < ZTREE_VALUE_ARRAY_SIZE; i++)
	{
		if(p_pZTREE_VALUE->m_pValues[i] != NULL)
		{
			nReturn++;
		}
		else
		{
			break;
		}
	}
	return nReturn;
}


BOOL	CZTreeBase::RemoveKeyValue(unsigned char * p_szKey, Z_INT64 p_nBufferLength, BOOL p_bFreeValues)
{
	//find the node to remove
	memset(m_pNodeStack, 0X00, sizeof(void *) * m_nStackDepth);
	m_nStackIndex = 0;
	ZTREE_VALUE_HEAD * pCurNodeHead = GetValue(m_pZTreeNodeRoot, p_szKey, 0, (unsigned int)p_nBufferLength * ZTREE_BITS_NUMBER_PER_CHAR);
	
	if(pCurNodeHead == NULL)
	{
		return FALSE;
	}
	
	//Release ZTREE_VALUE_HEAD and update m_pValueHead to NULL
	ReleaseZTreeValueHead(pCurNodeHead, p_bFreeValues);
	if(pCurNodeHead != NULL)
	{
		void * pNode = m_pNodeStack[(m_nStackIndex + m_nStackDepth - 1) % m_nStackDepth];
		if(pNode != NULL && (((ZTREE_BRANCH_NODE *)pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE))
		{
			if(((ZTREE_BRANCH_NODE *)pNode)->m_pValueHead == pCurNodeHead)
			{
				((ZTREE_BRANCH_NODE *)pNode)->m_pValueHead = NULL;
			}
			else
			{
				CZErrorProcessorBase::ProcessError("CZTreeBase::RemoveKeyValue: m_pValueHead of the last ZTREE_BRANCH_NODE node is null! ");
			}
		}
		else if(pNode != NULL)
		{
			if(((ZTREE_KEY_NODE *)pNode)->m_pValueHead == pCurNodeHead)
			{
				((ZTREE_KEY_NODE *)pNode)->m_pValueHead = NULL;
			}
			else
			{
				CZErrorProcessorBase::ProcessError("CZTreeBase::RemoveKeyValue: m_pValueHead of the last ZTREE_KEY_NODE node is null! ");
			}
		}
		else
		{
			CZErrorProcessorBase::ProcessError("CZTreeBase::RemoveKeyValue: The last node is null! ");
		}
	}
	
	//release the nodes in stack trace
	void * pNodeParent = m_pNodeStack[(m_nStackIndex + m_nStackDepth - 2) % m_nStackDepth];
	void * pNodeChild = m_pNodeStack[(m_nStackIndex + m_nStackDepth - 1) % m_nStackDepth];
	m_pNodeStack[(m_nStackIndex + m_nStackDepth - 1) % m_nStackDepth] = NULL;
	//Decrement m_nStackIndex
	m_nStackIndex = (m_nStackIndex + m_nStackDepth - 1) % m_nStackDepth;

	//Free child node if it is empty. (without children and index)
	while((pNodeParent != NULL) && (pNodeChild != NULL))
	{
		//release node
		if(((ZTREE_BRANCH_NODE *)pNodeChild)->m_nFlag == ZTREE_IS_BRANCH_NODE)
		{
			if(((ZTREE_BRANCH_NODE *)pNodeChild)->m_pBranchNodes[0] == NULL 
				&& ((ZTREE_BRANCH_NODE *)pNodeChild)->m_pBranchNodes[1] == NULL
			&& ((ZTREE_BRANCH_NODE *)pNodeChild)->m_pValueHead == NULL)
			{
				ZFree(pNodeChild);
			}
			else
			{
				break;
			}

			if(((ZTREE_BRANCH_NODE *)pNodeParent)->m_nFlag == ZTREE_IS_BRANCH_NODE)
			{
				if(((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[0] == pNodeChild)
				{
					((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[0] = NULL;
				}
				else if(((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[1] == pNodeChild)
				{
					((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[1] = NULL;
				}
				else
				{
					CZErrorProcessorBase::ProcessError("CZTreeBase::RemoveKeyValue: The branch node is not the child of the parent branch node! ");
				}
			}
			else //if(((ZTREE_KEY_NODE *)pNodeParent)->m_nFlag == ZTREE_IS_VALUE_NODE)
			{
				if(((ZTREE_KEY_NODE *)pNodeParent)->m_pNextNode == pNodeChild)
				{
					((ZTREE_KEY_NODE *)pNodeParent)->m_pNextNode = NULL;
				}
				else
				{
					CZErrorProcessorBase::ProcessError("CZTreeBase::RemoveKeyValue: The branch node is not the child of the parent key node! ");
				}
			}
		}
		else //if(((ZTREE_KEY_NODE *)pNodeChild)->m_nFlag == ZTREE_IS_VALUE_NODE)
		{
			if(((ZTREE_KEY_NODE *)pNodeChild)->m_pNextNode == NULL 
			&& ((ZTREE_KEY_NODE *)pNodeChild)->m_pValueHead == NULL)
			{
				ZFree(pNodeChild);
			}
			else
			{
				break;
			}

			if(((ZTREE_BRANCH_NODE *)pNodeParent)->m_nFlag == ZTREE_IS_BRANCH_NODE)
			{
				if(((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[0] == pNodeChild)
				{
					((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[0] = NULL;
				}
				else if(((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[1] == pNodeChild)
				{
					((ZTREE_BRANCH_NODE *)pNodeParent)->m_pBranchNodes[1] = NULL;
				}
				else
				{
					CZErrorProcessorBase::ProcessError("CZTreeBase::RemoveKeyValue: The key node is not the child of the parent branch node! ");
				}
			}
			else //if(((ZTREE_BRANCH_NODE *)pNodeParent)->m_nFlag == ZTREE_IS_VALUE_NODE)
			{
				if(((ZTREE_KEY_NODE *)pNodeParent)->m_pNextNode == pNodeChild)
				{
					((ZTREE_KEY_NODE *)pNodeParent)->m_pNextNode = NULL;
				}
				else
				{
					CZErrorProcessorBase::ProcessError("CZTreeBase::RemoveKeyValue: The key node is not the child of the parent key node! ");
				}
			}
		}
	
		//Move to the parent node
		pNodeParent = m_pNodeStack[(m_nStackIndex + m_nStackDepth - 2) % m_nStackDepth];
		pNodeChild = m_pNodeStack[(m_nStackIndex + m_nStackDepth - 1) % m_nStackDepth];
		m_pNodeStack[(m_nStackIndex + m_nStackDepth - 1) % m_nStackDepth] = NULL;
		//Decrement m_nStackIndex
		m_nStackIndex = (m_nStackIndex + m_nStackDepth - 1) % m_nStackDepth;
		}
	
	return TRUE;
}

BOOL	CZTreeBase::SetKeyValue(unsigned char * p_szKey, unsigned int p_nBufferLength, void * p_pValue, BOOL p_bFreeValues)
{
	RemoveKeyValue(p_szKey, p_nBufferLength, p_bFreeValues);
	return AddKeyValue(m_pZTreeNodeRoot, p_szKey, 0, p_nBufferLength * ZTREE_BITS_NUMBER_PER_CHAR, p_pValue);
}

int	CZTreeBase::GetLongestCommonBitNumber(void * p_pNode, unsigned char * p_szKey, unsigned int p_nBitLevelStart, unsigned int p_nBitLevelEnd)
{
	void * 	pParentNode = p_pNode;
	int		nParentBranchIndex = -1;
	while(true)
	{
		if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
		{
			if(p_nBitLevelStart == p_nBitLevelEnd)
			{
				return p_nBitLevelStart;
			}
			int nBranchIndex = GetBit(p_szKey, p_nBitLevelStart);
			if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] == NULL)
			{
				return p_nBitLevelStart;
			}//if(((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex] == NULL)
			else
			{
				pParentNode = p_pNode;
				nParentBranchIndex = nBranchIndex;
				
				p_nBitLevelStart++;
				p_pNode = ((ZTREE_BRANCH_NODE *)p_pNode)->m_pBranchNodes[nBranchIndex];
				continue;
			}
		}//if(((ZTREE_BRANCH_NODE *)p_pNode)->m_nFlag == ZTREE_IS_BRANCH_NODE)
		else //p_pNode is a ZTREE_KEY_NODE. Split this ZTREE_KEY_NODE
		{
			unsigned int nMaxBitNumber = ((p_nBitLevelEnd - p_nBitLevelStart) <= (unsigned int)(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart) ? (p_nBitLevelEnd - p_nBitLevelStart) : (unsigned int)(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart));
			unsigned int nMatchBitIndex = GetNonMatchBitIndex(p_szKey, ((ZTREE_KEY_NODE *)p_pNode)->m_pKey, p_nBitLevelStart, ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart, nMaxBitNumber);
			unsigned int nSplitBitIndex = p_nBitLevelStart + nMatchBitIndex;

			if(nMatchBitIndex < (unsigned int)(((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart))
			{
				return nSplitBitIndex;
			}
			if(p_nBitLevelStart + (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart) == p_nBitLevelEnd)
			{
				return p_nBitLevelEnd;
			}

			if(((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode == NULL)
			{
				return p_nBitLevelStart + (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart);
			}
			
			pParentNode = p_pNode;
			nParentBranchIndex = -1;
			
			p_nBitLevelStart += (((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelEnd - ((ZTREE_KEY_NODE *)p_pNode)->m_nBitLevelStart);
			p_pNode = ((ZTREE_KEY_NODE *)p_pNode)->m_pNextNode;
			continue;
		} //p_pNode is a ZTREE_KEY_NODE. Split this ZTREE_KEY_NODE
	}//while(TRUE)
	return p_nBitLevelStart;
}

int	CZTreeBase::GetLongestCommonBitNumber(unsigned char * p_szKey, unsigned int p_nBufferLength)
{
	return GetLongestCommonBitNumber(m_pZTreeNodeRoot, p_szKey, 0, (unsigned int)p_nBufferLength * ZTREE_BITS_NUMBER_PER_CHAR);
}
