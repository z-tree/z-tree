/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#include "ZMemoryPool.h"
#include "ZTreeOneValue.h"
#include "ZErrorProcessorBase.h"


CZTreeOneValue::CZTreeOneValue(void)
{
}

CZTreeOneValue::~CZTreeOneValue(void)
{
}

void * CZTreeOneValue::ZMalloc(size_t size)
{
	return m_memoryPool.Malloc(size);
}

void CZTreeOneValue::ZFree(void* ptr)
{
	m_memoryPool.Free(ptr);
}

void CZTreeOneValue::SetQuickMode(BOOL p_bQuickMode)
{
	m_memoryPool.SetQuickMode(TRUE);
}

void	CZTreeOneValue::SetMemeryPoolReleaser(CZMemoryPool * p_pMemeryPool)
{
	m_ZMemoryPoolReleaser.SetMemeryPool(p_pMemeryPool);
	m_pMemeryReleaserBase = &m_ZMemoryPoolReleaser;
}

void  *	CZTreeOneValue::GetValueByKey(unsigned char * p_szKey, Z_INT64 p_nBufferLength)
{
	memset(m_pNodeStack, 0X00, sizeof(void *) * m_nStackDepth);
	m_nStackIndex = 0;
	return (void *)GetValue(m_pZTreeNodeRoot, p_szKey, 0, (unsigned int)p_nBufferLength * ZTREE_BITS_NUMBER_PER_CHAR);
}

