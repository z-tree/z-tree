/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#ifndef _ZTREE_MEMERY_Z_TREE_H_
#define _ZTREE_MEMERY_Z_TREE_H_

#include "ZCommon.h"
#include "ZMemeryReleaserBase.h"
#include "ZTreeBase.h"

/**
 * CZMemoryZTree
 * 
 * CZMemoryZTree is an internal class used by CZMemoryPool to allocate memory.
 * CZMemoryZTree should not be used by your application.
 * 
 */

class CZMemoryZTree : public CZTreeBase
{
public:
	CZMemoryZTree(void);
	virtual ~CZMemoryZTree(void);
	
public:
	BOOL				CheckMemoryLeak();
	
private:
	BOOL				CheckMemoryLeakInValues(ZTREE_VALUE_HEAD * pZTreeValueHead);
	BOOL				CheckMemoryLeakInNode(void * p_pNode);
};

#endif