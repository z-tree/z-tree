/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#ifndef _ZTREE_MEMERY_POOL_H_
#define _ZTREE_MEMERY_POOL_H_

#include "ZCommon.h"
#include "ZMemeryReleaserBase.h"
#include "ZMemeryReleaserFree.h"
#include "ZMemeryReleaserNULL.h"
#include "ZMemoryZTree.h"


//Each memory returned to the customer includes a header

//(RAW_MEMORY_HEADER + MEMORY_UNIT_HEADER) is the head for memory from windows directly
typedef struct struRawMemoryHeader 
{
	//Memory size to check the check code after the memory unit
	unsigned Z_INT64				m_nMemorySizeRequested;
	
	//Each memory includes a MEMORY_UNIT_HEADER before the address returned to the customer
	//MEMORY_UNIT_HEADER				m_unitHeader;
	
	//Memory returned to user will be included here with an extra byte as m_chCheckCodeSuffix
	//unsigned char					m_chCheckCodeSuffix;
}RAW_MEMORY_HEADER;

//MEMORY_UNIT_HEADER is the header allocated from memory pool
typedef struct struMemoryUnitHeader
{
	//m_pSystemMemoryAddress is the address of the MEMORY_BLOCK_XXXX. It is the address allocated from windows system.
	void *							m_pSystemMemoryAddress;
	
	//Memory returned to user will be included here with an extra byte as m_chCheckCodeSuffix
	//unsigned char					m_chCheckCodeSuffix;
}MEMORY_UNIT_HEADER;



//Memory Pool Block definitions
//MEMORY_POOL_BLOCK_SMALL includes 64 memory units
typedef struct struMemoryPoolBlockHead
{
	//Unit block small, medium or huge, THRESHOLD_COUNT_BLOCK_SMALL, THRESHOLD_COUNT_BLOCK_MEDIUM, THRESHOLD_COUNT_BLOCK_HUGE
	unsigned Z_INT64				m_nBlockFlag;
	
	//Bitmap. m_nBitmapFull indicates if a child block or unit is full, m_nBitmapEmpty indicates if a child block or unit is empty
	unsigned Z_INT64				m_nBitmapFull;
	unsigned Z_INT64				m_nBitmapEmpty;
	
	//Varialbles for Memory Pool
	//m_nUnitSizeRequested is the size requested by user.
	unsigned Z_INT64				m_nUnitSizeRequested;
	//m_nUnitSizeReal = m_nUnitSizeRequested + sizeof(MEMORY_UNIT_HEADER) + sizeof(m_chCheckCodeSuffix);
	unsigned Z_INT64				m_nUnitSizeReal; 
	void *							m_pMemoryPoolAddress;
	
	//Next MEMORY_BLOCK_***
	void						 * 	m_pNextBlock;
}MEMORY_POOL_BLOCK_HEAD;

typedef struct struMemoryPoolBlockSmall
{
	//Each pool has a head
	MEMORY_POOL_BLOCK_HEAD			m_poolHead;
	
	//Full Empty Flags and Indexes for the next available memory unit
	Z_INT64    m_nIndexLevel1;
	//Z_INT64    m_nIndexLevel2;
	//Z_INT64    m_nIndexLevel3;
	
	//...the rest are real memory for memory units
}MEMORY_POOL_BLOCK_SMALL;


//MEMORY_POOL_BLOCK_MEDIUM includes 4096 memory units
typedef struct struMemoryPoolBlockMedium
{
	//Each pool has a head
	MEMORY_POOL_BLOCK_HEAD			m_poolHead;
	
	// Full Empty Flags and Indexes for the next available memory unit
	unsigned Z_INT64				m_nBitmapFull64[64];
	
	Z_INT64    m_nIndexLevel1;
	Z_INT64    m_nIndexLevel2;
	//Z_INT64    m_nIndexLevel3;
	
	//...the rest are real memory for memory units
}MEMORY_POOL_BLOCK_MEDIUM;

//MEMORY_POOL_BLOCK_HUGE includes 4096 * 64 memory units
typedef struct struMemoryPoolBlockHuge
{
	//Each pool has a head
	MEMORY_POOL_BLOCK_HEAD			m_poolHead;
	
	// Full Empty Flags and Indexes for the next available memory unit
	unsigned Z_INT64				m_nBitmapFull64[64];
	unsigned Z_INT64				m_nBitmapEmpty64[64];
	unsigned Z_INT64				m_nBitmapFull4096[4096];
	
	Z_INT64    m_nIndexLevel1;
	Z_INT64    m_nIndexLevel2;
	Z_INT64    m_nIndexLevel3;
	
	//...the rest are real memory for memory units
}MEMORY_POOL_BLOCK_HUGE;

//MEMORY_POOL_BLOCK_GIGANTIC includes 4096 * 4096 memory units
typedef struct struMemoryPoolBlockGigantic
{
	//Each pool has a head
	MEMORY_POOL_BLOCK_HEAD			m_poolHead;
	
	// Full Empty Flags and Indexes for the next available memory unit
	unsigned Z_INT64				m_nBitmapFull64[64];
	unsigned Z_INT64				m_nBitmapEmpty64[64];
	unsigned Z_INT64				m_nBitmapFull4096[4096];
	unsigned Z_INT64				m_nBitmapEmpty4096[4096];
	unsigned Z_INT64				m_nBitmapFull262144[262144];
	
	Z_INT64    m_nIndexLevel1;
	Z_INT64    m_nIndexLevel2;
	Z_INT64    m_nIndexLevel3;
	Z_INT64    m_nIndexLevel4;
	
	//...the rest are real memory for memory units
}MEMORY_POOL_BLOCK_GIGANTIC;

/**
 * CZMemoryPool
 * 
 * CZMemoryPool is the class for Z-Memory Pool. CZMemoryPool will free memory automatically following RAII rule.
 * CZMemoryPool is also capable of detecting invalid memory address and memory overflow. 
 * CZMemoryPool provides the following functions.
 * 1. Allocate and free memory. This is similar to the functions malloc()/free() provided in C.
 * 	void *							Malloc(size_t size);
 * 	void							Free(void* ptr);
 * 
 * 2. CZMemoryPool provides the following functions to disable memory leak and memory overflow checking and improve CZMemoryPool speed. 
 * 	//SetQuickMode(TRUE) disables memory leak and memory overflow checking. 
 * 	//SetQuickMode(TRUE) improves the speed of CZMemoryPool.
 * 	void							SetQuickMode(BOOL p_bQuickMode);
 * 	//SetCheckMemoryLeak(FALSE) only disables memory leak checking. 
 * 	//SetCheckMemoryLeak(FALSE) improves the speed of CZMemoryPool.
 * 	void							SetCheckMemoryLeak(BOOL p_bCheckMemoryLeak);
 * 	//To free Memory in Quick Mode, We MUST call FreeMemoryPool(). The CZMemoryPool.Free(void* ptr) doesn't work.
 * 	void							FreeMemoryPool();
 * 
 * 3. Release CPP objects. To release CPP objects, you need to assign a memory release for CPP and add the CPP objects to CZMemoryPool. 
 * 	void							SetCPPObjectReleaser(CZMemeryReleaserBase * p_pCPPObjectReleaserBase);
 * 	void *							AddObject(void * pObject);
 * 	BOOL							DeleteObject(void * pObject);
 * 
 */

class CZMemoryPool
{
public:
	CZMemoryPool(BOOL p_bQuickMode = FALSE);
	~CZMemoryPool(void);

	static const unsigned Z_INT64	THRESHOLD_COUNT_RAW_MALLOC = 5;
	static const unsigned Z_INT64	THRESHOLD_COUNT_BLOCK_SMALL = 320; //5 blocks and Each small block has 64 units
	static const unsigned Z_INT64	THRESHOLD_COUNT_BLOCK_MEDIUM = 20480; //5 blocks and Each small block has 4096 units
	static const unsigned Z_INT64	THRESHOLD_COUNT_BLOCK_HUGE = 1310720; //5 blocks and Each small block has 4096 * 64 units
	static const unsigned Z_INT64	THRESHOLD_COUNT_BLOCK_GIGANTIC = 83886080; //5 blocks and Each small block has 4096 * 4096 units

	static const unsigned Z_INT64	BLOCK_IS_FULL = 0XFFFFFFFFFFFFFFFF;
	static const unsigned Z_INT64	BLOCK_IS_EMPTY = 0X00;

public:
	//Functions for C malloc/free
	void *							Malloc(size_t size);
	void							Free(void* ptr);
	
	//SetQuickMode(TRUE) disables memory leak and memory overflow checking. 
	//SetQuickMode(TRUE) improves the speed of CZMemoryPool.
	void							SetQuickMode(BOOL p_bQuickMode);
	//SetCheckMemoryLeak(FALSE) only disables memory leak checking. 
	//SetCheckMemoryLeak(FALSE) improves the speed of CZMemoryPool.
	void							SetCheckMemoryLeak(BOOL p_bCheckMemoryLeak);
	//To free Memory in Quick Mode, We MUST call FreeMemoryPool(). The CZMemoryPool.Free(void* ptr) doesn't work.
	void							FreeMemoryPool();

	//Functions for CPP objects.
	void							SetCPPObjectReleaser(CZMemeryReleaserBase * p_pCPPObjectReleaserBase);
	void *							AddObject(void * pObject);
	BOOL							DeleteObject(void * pObject);
	
private:
	//static or global variables
	static const unsigned Z_INT64	MEMORY_POOL_NUMBER = 1025;
	static const unsigned Z_INT64	BITS_NUMBER_PER_INT64 = 64;
	static const unsigned int		CHAR_NUMBER_PER_INT = sizeof(int);
	
	//THRESHOLD 
	//When the requested memory size is greater than THRESHOLD_UNIT_SIZE_BLOCK_HUGE, will not use block huge.
	static const unsigned Z_INT64	THRESHOLD_UNIT_SIZE_BLOCK_HUGE = 512; //128 bytes per unit and Each small block has 4096 units
	static const unsigned Z_INT64	THRESHOLD_UNIT_SIZE_BLOCK_GIGANTIC = 32; //128 bytes per unit and Each small block has 4096 units
	
	static unsigned Z_INT64			m_int64Bits[BITS_NUMBER_PER_INT64];
	
	//variables for objects
	//While running in quick mode, CZMemoryPool will not check CheckCode. The function Free() doesn't work at all.
	BOOL							m_bCheckMemoryLeak;
	BOOL							m_bQuickMode;
	
	CZMemoryZTree					m_objMemoryZTreeAll;
	CZMemeryReleaserFree 			m_MemeryReleaserFree;
	CZMemeryReleaserNULL 			m_MemeryReleaserNULL;
	//m_objMemoryZTreeInList doesn't need a releaser
	CZMemoryZTree					m_objMemoryZTreeInList;
	CZMemoryZTree					m_objMemoryZTreeForCPPObjects;
	CZMemeryReleaserBase * 			m_pCPPObjectReleaserBase;
	//m_chCheckCode my be different in different CZMemoryPool objects
	static unsigned char			m_chCheckCodeSeed;
	unsigned char					m_chCheckCode;
	//When m_nTotalAllocatedCount is less than THRESHOLD_COUNT_RAW_MALLOC, 
	//will call Malloc directly without initializaing memory pool
	unsigned Z_INT64				m_nTotalAllocatedCount;
	
	//Linked List Pool for memory block
	void **							m_pPoolPointer;
	Z_INT64 *						m_pPoolCounter;

private:
	void *							MallocFromSystem(size_t size);
	//Create Memory Pool
	BOOL							CreateMomeryPoolBlockSmall(size_t size);
	BOOL							CreateMomeryPoolBlockMedium(size_t size);
	BOOL							CreateMomeryPoolBlockHuge(size_t size);
	BOOL							CreateMomeryPoolBlockGigantic(size_t size);
	BOOL							CreateMomeryPoolBlock(size_t size);
	
	//Allocate memory from pool block
	void *							AllocateFromPoolBlockSmall(size_t size);
	void *							AllocateFromPoolBlockMedium(size_t size);
	void *							AllocateFromPoolBlockHuge(size_t size);
	void *							AllocateFromPoolBlockGigantic(size_t size);
	void *							AllocateFromPoolBlock(size_t size);
	
	//Free memoy from pool block
	BOOL							RemovePoolFromList(unsigned Z_INT64 p_nUnitSizeRequested, void * p_pMemoryPool);
	BOOL							FreeFromPoolBlockSmall(MEMORY_POOL_BLOCK_SMALL * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty);
	BOOL							FreeFromPoolBlockMedium(MEMORY_POOL_BLOCK_MEDIUM * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty);
	BOOL							FreeFromPoolBlockHuge(MEMORY_POOL_BLOCK_HUGE * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty);
	BOOL							FreeFromPoolBlockGigantic(MEMORY_POOL_BLOCK_GIGANTIC * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty);
};

#endif