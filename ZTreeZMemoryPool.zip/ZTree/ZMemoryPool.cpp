/*
 *   Copyright 2016 Z-Tree
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *   
 *   The patent for Z-Tree can also be distributed for free. Please name the 
 *   data structure "Z-Tree" in your documents or publications.
 *       http://www.patentsencyclopedia.com/app/20140222870
 */

#include "ZMemoryPool.h"
#include "ZErrorProcessorBase.h"

unsigned Z_INT64	CZMemoryPool::m_int64Bits[BITS_NUMBER_PER_INT64] = {	0X1, 0X2, 0X4, 0X8, 0X10, 0X20, 0X40, 0X80, \
													0X100, 0X200, 0X400, 0X800, 0X1000, 0X2000, 0X4000, 0X8000, \
													0X10000, 0X20000, 0X40000, 0X80000, 0X100000, 0X200000, 0X400000, 0X800000, \
													0X1000000, 0X2000000, 0X4000000, 0X8000000, 0X10000000, 0X20000000, 0X40000000, 0X80000000, \
													0X100000000, 0X200000000, 0X400000000, 0X800000000, 0X1000000000, 0X2000000000, 0X4000000000, 0X8000000000, \
													0X10000000000, 0X20000000000, 0X40000000000, 0X80000000000, 0X100000000000, 0X200000000000, 0X400000000000, 0X800000000000, \
													0X1000000000000, 0X2000000000000, 0X4000000000000, 0X8000000000000, 0X10000000000000, 0X20000000000000, 0X40000000000000, 0X80000000000000, \
													0X100000000000000, 0X200000000000000, 0X400000000000000, 0X800000000000000, 0X1000000000000000, 0X2000000000000000, 0X4000000000000000, 0X8000000000000000};
unsigned char		CZMemoryPool::m_chCheckCodeSeed = 0;

CZMemoryPool::CZMemoryPool(BOOL p_bQuickMode)
{
	m_bQuickMode = p_bQuickMode;
	m_bCheckMemoryLeak = TRUE;
	m_pCPPObjectReleaserBase = NULL;
	m_chCheckCodeSeed++;
	m_chCheckCode = m_chCheckCodeSeed;
	m_nTotalAllocatedCount = 0;
	m_pPoolPointer = NULL;
	m_pPoolCounter = NULL;

	m_objMemoryZTreeAll.SetMemeryReleaser(&m_MemeryReleaserFree);
	m_objMemoryZTreeAll.InitZTree();
	m_objMemoryZTreeInList.SetMemeryReleaser(&m_MemeryReleaserNULL);
	m_objMemoryZTreeInList.InitZTree();
	m_objMemoryZTreeForCPPObjects.SetMemeryReleaser(m_pCPPObjectReleaserBase);
	m_objMemoryZTreeForCPPObjects.InitZTree();
}

CZMemoryPool::~CZMemoryPool(void)
{
	//This is still to be udpated to allocated memory pool blocks
	if(!m_bQuickMode && m_bCheckMemoryLeak)
	{
		m_objMemoryZTreeInList.CheckMemoryLeak();
		m_objMemoryZTreeAll.CheckMemoryLeak();
		m_objMemoryZTreeForCPPObjects.CheckMemoryLeak();
	}
	m_objMemoryZTreeInList.ReleaseZTree(FALSE);
	m_objMemoryZTreeAll.ReleaseZTree(TRUE);
	m_objMemoryZTreeForCPPObjects.ReleaseZTree(TRUE);
	
	if(m_pPoolPointer != NULL)
	{
		free(m_pPoolPointer);
		m_pPoolPointer = NULL;
	}
	
	if(m_pPoolCounter != NULL)
	{
		free(m_pPoolCounter);
		m_pPoolCounter = NULL;
	}
}


void CZMemoryPool::SetQuickMode(BOOL p_bQuickMode)
{
	m_bQuickMode = TRUE;
}

void CZMemoryPool::SetCheckMemoryLeak(BOOL p_bCheckMemoryLeak)
{
	if(m_nTotalAllocatedCount > 0)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: Can't disable/enable checking memory leak after allocating memory! ");
		return;
	}
	m_bCheckMemoryLeak = p_bCheckMemoryLeak;
}

void	CZMemoryPool::SetCPPObjectReleaser(CZMemeryReleaserBase * p_pCPPObjectReleaserBase)
{
	m_pCPPObjectReleaserBase = p_pCPPObjectReleaserBase;
	m_objMemoryZTreeForCPPObjects.SetMemeryReleaser(m_pCPPObjectReleaserBase);
}

//This function will free memory pool. The tree also needs to be initialized as they will be used again.
void CZMemoryPool::FreeMemoryPool()
{
	if(!m_bQuickMode && m_bCheckMemoryLeak)
	{
		m_objMemoryZTreeInList.CheckMemoryLeak();
		m_objMemoryZTreeAll.CheckMemoryLeak();
		m_objMemoryZTreeForCPPObjects.CheckMemoryLeak();
	}
	m_objMemoryZTreeInList.ReleaseZTree(FALSE);
	m_objMemoryZTreeAll.ReleaseZTree(TRUE);
	m_objMemoryZTreeForCPPObjects.ReleaseZTree(TRUE);

	m_objMemoryZTreeAll.InitZTree();
	m_objMemoryZTreeInList.InitZTree();
	m_objMemoryZTreeForCPPObjects.InitZTree();
	
	if(m_pPoolPointer != NULL)
	{
		memset(m_pPoolPointer, 0X00, sizeof(void *) * MEMORY_POOL_NUMBER);
	}
}

void * CZMemoryPool::MallocFromSystem(size_t size)
{
	//allocate node and set RAW_MEMORY_HEADER values
	RAW_MEMORY_HEADER * pSystemMemoryAddress = (RAW_MEMORY_HEADER *) malloc((sizeof(RAW_MEMORY_HEADER) + sizeof(MEMORY_UNIT_HEADER)) + size + sizeof(m_chCheckCode));
	if(!pSystemMemoryAddress)
	{
		return NULL;
	}
	
	pSystemMemoryAddress->m_nMemorySizeRequested = size;
	MEMORY_UNIT_HEADER * pMemoryUnitHeader = (MEMORY_UNIT_HEADER *)((unsigned char *)pSystemMemoryAddress + (sizeof(RAW_MEMORY_HEADER)));
	pMemoryUnitHeader->m_pSystemMemoryAddress = pSystemMemoryAddress;
	
	//Set Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pSystemMemoryAddress) + (sizeof(RAW_MEMORY_HEADER) + sizeof(MEMORY_UNIT_HEADER)) + size;
	* pCheckCodeSuffix = m_chCheckCode;

	//insert the pointer into ZTree
	if(!m_objMemoryZTreeAll.AddKeyValue((unsigned char *) &pSystemMemoryAddress, sizeof(pSystemMemoryAddress), pSystemMemoryAddress))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: MallocFromSystem: Fail to insert node into tree! This may cause memory leak! ");
	}

	return ((unsigned char *)pSystemMemoryAddress) + (sizeof(RAW_MEMORY_HEADER) + sizeof(MEMORY_UNIT_HEADER));
}



//Create Memory Pool
BOOL	CZMemoryPool::CreateMomeryPoolBlockSmall(size_t size)
{
	//Create Memory Pool
	Z_INT64 nUnitSizeReal = sizeof(MEMORY_UNIT_HEADER) + size + sizeof(m_chCheckCode);
	if(m_bQuickMode)
	{
		nUnitSizeReal = size;
	}
	if(size >= CHAR_NUMBER_PER_INT)
	{
		//Align nUnitSizeReal with char number per int. nUnitSizeReal should be n * sizeof(int).
		nUnitSizeReal = (nUnitSizeReal + CHAR_NUMBER_PER_INT - 1) / CHAR_NUMBER_PER_INT * CHAR_NUMBER_PER_INT;
	}
	
	
	MEMORY_POOL_BLOCK_SMALL *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_SMALL *) malloc(sizeof(MEMORY_POOL_BLOCK_SMALL) + nUnitSizeReal * BITS_NUMBER_PER_INT64);
	if(pMemoryPoolBlock == NULL)
	{
		return FALSE;
	}
	
	memset(pMemoryPoolBlock, 0, sizeof(MEMORY_POOL_BLOCK_SMALL) + nUnitSizeReal * BITS_NUMBER_PER_INT64);
	pMemoryPoolBlock->m_poolHead.m_nBlockFlag = THRESHOLD_COUNT_BLOCK_SMALL;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeRequested = size;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal = nUnitSizeReal;
	pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress = ((unsigned char *)pMemoryPoolBlock) + sizeof(MEMORY_POOL_BLOCK_SMALL);
	
	//insert the pointer into m_pPoolPointer and ZTree
	m_pPoolPointer[size] = pMemoryPoolBlock;
	if(!m_objMemoryZTreeAll.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: MallocFromSystem: Fail to insert node into tree! This may cause memory leak! ");
	}
	m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock);
	return TRUE;
}
BOOL	CZMemoryPool::CreateMomeryPoolBlockMedium(size_t size)
{
	//Create Memory Pool
	Z_INT64 nUnitSizeReal = sizeof(MEMORY_UNIT_HEADER) + size + sizeof(m_chCheckCode);
	if(m_bQuickMode)
	{
		nUnitSizeReal = size;
	}
	if(size >= CHAR_NUMBER_PER_INT)
	{
		//Align nUnitSizeReal with char number per int. nUnitSizeReal should be n * sizeof(int).
		nUnitSizeReal = (nUnitSizeReal + CHAR_NUMBER_PER_INT - 1) / CHAR_NUMBER_PER_INT * CHAR_NUMBER_PER_INT;
	}
	
	MEMORY_POOL_BLOCK_MEDIUM *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_MEDIUM *) malloc(sizeof(MEMORY_POOL_BLOCK_MEDIUM) + nUnitSizeReal * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64);
	if(pMemoryPoolBlock == NULL)
	{
		return FALSE;
	}
	
	memset(pMemoryPoolBlock, 0, sizeof(MEMORY_POOL_BLOCK_MEDIUM) + nUnitSizeReal * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64);
	pMemoryPoolBlock->m_poolHead.m_nBlockFlag = THRESHOLD_COUNT_BLOCK_MEDIUM;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeRequested = size;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal = nUnitSizeReal;
	pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress = ((unsigned char *)pMemoryPoolBlock) + sizeof(MEMORY_POOL_BLOCK_MEDIUM);
	
	//insert the pointer into m_pPoolPointer and ZTree
	m_pPoolPointer[size] = pMemoryPoolBlock;
	if(!m_objMemoryZTreeAll.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: MallocFromSystem: Fail to insert node into tree! This may cause memory leak! ");
	}
	m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock);
	return TRUE;
}
BOOL	CZMemoryPool::CreateMomeryPoolBlockHuge(size_t size)
{
	//Create Memory Pool
	Z_INT64 nUnitSizeReal = sizeof(MEMORY_UNIT_HEADER) + size + sizeof(m_chCheckCode);
	if(m_bQuickMode)
	{
		nUnitSizeReal = size;
	}
	if(size >= CHAR_NUMBER_PER_INT)
	{
		//Align nUnitSizeReal with char number per int. nUnitSizeReal should be n * sizeof(int).
		nUnitSizeReal = (nUnitSizeReal + CHAR_NUMBER_PER_INT - 1) / CHAR_NUMBER_PER_INT * CHAR_NUMBER_PER_INT;
	}
	
	MEMORY_POOL_BLOCK_HUGE *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_HUGE *) malloc(sizeof(MEMORY_POOL_BLOCK_HUGE) + nUnitSizeReal * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64);
	if(pMemoryPoolBlock == NULL)
	{
		return FALSE;
	}
	
	memset(pMemoryPoolBlock, 0, sizeof(MEMORY_POOL_BLOCK_HUGE) + nUnitSizeReal * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64);
	pMemoryPoolBlock->m_poolHead.m_nBlockFlag = THRESHOLD_COUNT_BLOCK_HUGE;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeRequested = size;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal = nUnitSizeReal;
	pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress = ((unsigned char *)pMemoryPoolBlock) + sizeof(MEMORY_POOL_BLOCK_HUGE);
	
	//insert the pointer into m_pPoolPointer and ZTree
	m_pPoolPointer[size] = pMemoryPoolBlock;
	if(!m_objMemoryZTreeAll.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: MallocFromSystem: Fail to insert node into tree! This may cause memory leak! ");
	}
	m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock);
	return TRUE;
}


BOOL	CZMemoryPool::CreateMomeryPoolBlockGigantic(size_t size)
{
	//Create Memory Pool
	Z_INT64 nUnitSizeReal = sizeof(MEMORY_UNIT_HEADER) + size + sizeof(m_chCheckCode);
	if(m_bQuickMode)
	{
		nUnitSizeReal = size;
	}
	if(size >= CHAR_NUMBER_PER_INT)
	{
		//Align nUnitSizeReal with char number per int. nUnitSizeReal should be n * sizeof(int).
		nUnitSizeReal = (nUnitSizeReal + CHAR_NUMBER_PER_INT - 1) / CHAR_NUMBER_PER_INT * CHAR_NUMBER_PER_INT;
	}
	
	MEMORY_POOL_BLOCK_GIGANTIC *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_GIGANTIC *) malloc(sizeof(MEMORY_POOL_BLOCK_GIGANTIC) + nUnitSizeReal * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64);
	if(pMemoryPoolBlock == NULL)
	{
		return FALSE;
	}
	
	memset(pMemoryPoolBlock, 0, sizeof(MEMORY_POOL_BLOCK_GIGANTIC) + nUnitSizeReal * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64 * BITS_NUMBER_PER_INT64);
	pMemoryPoolBlock->m_poolHead.m_nBlockFlag = THRESHOLD_COUNT_BLOCK_GIGANTIC;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeRequested = size;
	pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal = nUnitSizeReal;
	pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress = ((unsigned char *)pMemoryPoolBlock) + sizeof(MEMORY_POOL_BLOCK_GIGANTIC);
	
	//insert the pointer into m_pPoolPointer and ZTree
	m_pPoolPointer[size] = pMemoryPoolBlock;
	if(!m_objMemoryZTreeAll.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: MallocFromSystem: Fail to insert node into tree! This may cause memory leak! ");
	}
	m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &pMemoryPoolBlock, sizeof(pMemoryPoolBlock), pMemoryPoolBlock);
	return TRUE;
}


BOOL	CZMemoryPool::CreateMomeryPoolBlock(size_t size)
{
	if(size <= THRESHOLD_UNIT_SIZE_BLOCK_GIGANTIC && m_pPoolCounter[size] >= THRESHOLD_COUNT_BLOCK_HUGE)
	{
		if(CreateMomeryPoolBlockGigantic(size))
		{
			return TRUE;
		}
	}
	if(size <= THRESHOLD_UNIT_SIZE_BLOCK_HUGE && m_pPoolCounter[size] >= THRESHOLD_COUNT_BLOCK_MEDIUM)
	{
		if(CreateMomeryPoolBlockHuge(size))
		{
			return TRUE;
		}
	}
	if(m_pPoolCounter[size] >= THRESHOLD_COUNT_BLOCK_SMALL)
	{
		if(CreateMomeryPoolBlockMedium(size))
		{
			return TRUE;
		}
		else
		{
			CZErrorProcessorBase::ProcessError("Memory Pool: Fail to allocate 4096 units memory pool. Will allocate 64 bit units memory pool!");
		}
	}
	return CreateMomeryPoolBlockSmall(size);
}



//Allocate Memory from memory pool
void *	CZMemoryPool::AllocateFromPoolBlockSmall(size_t size)
{
	MEMORY_POOL_BLOCK_SMALL *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_SMALL *) m_pPoolPointer[size];
	//Calculate indexes
	Z_INT64    nIndexLevel1 = 0;
	if(pMemoryPoolBlock->m_nIndexLevel1 < BITS_NUMBER_PER_INT64 
	&& (pMemoryPoolBlock->m_poolHead.m_nBitmapFull & m_int64Bits[pMemoryPoolBlock->m_nIndexLevel1]) == 0)
	{
		nIndexLevel1 = pMemoryPoolBlock->m_nIndexLevel1;
		pMemoryPoolBlock->m_nIndexLevel1++;
	}
	else
	{
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_poolHead.m_nBitmapFull & m_int64Bits[i]) == 0)
			{
				nIndexLevel1 = i;
				break;
			}
		}
	}

	//Update full flag
	pMemoryPoolBlock->m_poolHead.m_nBitmapFull |= m_int64Bits[nIndexLevel1];
	//Update empty flag
	pMemoryPoolBlock->m_poolHead.m_nBitmapEmpty |= m_int64Bits[nIndexLevel1];

	//Calculate offset
	Z_INT64    nOffset = nIndexLevel1 * pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal;
	if(m_bQuickMode)
	{
		return (((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	}
	
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	pMemoryUnit->m_pSystemMemoryAddress = pMemoryPoolBlock;
	//Set Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + size;
	* pCheckCodeSuffix = m_chCheckCode;

	return ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER);
}
void *	CZMemoryPool::AllocateFromPoolBlockMedium(size_t size)
{
	MEMORY_POOL_BLOCK_MEDIUM *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_MEDIUM *) m_pPoolPointer[size];
	//Calculate indexes
	Z_INT64    nIndexLevel1 = 0;
	Z_INT64    nIndexLevel2 = 0;
	if(pMemoryPoolBlock->m_nIndexLevel1 < BITS_NUMBER_PER_INT64 
	&& (pMemoryPoolBlock->m_nBitmapFull64[pMemoryPoolBlock->m_nIndexLevel1] & m_int64Bits[pMemoryPoolBlock->m_nIndexLevel2]) == 0)
	{
		nIndexLevel1 = pMemoryPoolBlock->m_nIndexLevel1;
		nIndexLevel2 = pMemoryPoolBlock->m_nIndexLevel2;
		pMemoryPoolBlock->m_nIndexLevel2++;
		if(pMemoryPoolBlock->m_nIndexLevel2 >= BITS_NUMBER_PER_INT64) {
			pMemoryPoolBlock->m_nIndexLevel2 = 0;
			pMemoryPoolBlock->m_nIndexLevel1++;
		}
	}
	else
	{
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_poolHead.m_nBitmapFull & m_int64Bits[i]) == 0)
			{
				nIndexLevel1 = i;
				break;
			}
		}
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] & m_int64Bits[i]) == 0)
			{
				nIndexLevel2 = i;
				break;
			}
		}
	}

	//Update full flag
	pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] |= m_int64Bits[nIndexLevel2];
	if(pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] == BLOCK_IS_FULL)
	{
		pMemoryPoolBlock->m_poolHead.m_nBitmapFull |= m_int64Bits[nIndexLevel1];
	}
	//Update empty flag
	pMemoryPoolBlock->m_poolHead.m_nBitmapEmpty |= m_int64Bits[nIndexLevel1];

	//Calculate offset
	Z_INT64    nOffset = (nIndexLevel1 * 64 + nIndexLevel2) * pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal;
	if(m_bQuickMode)
	{
		return (((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	}
	
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	pMemoryUnit->m_pSystemMemoryAddress = pMemoryPoolBlock;
	//Set Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + size;
	* pCheckCodeSuffix = m_chCheckCode;

	return ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER);
}
void *	CZMemoryPool::AllocateFromPoolBlockHuge(size_t size)
{
	MEMORY_POOL_BLOCK_HUGE *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_HUGE *) m_pPoolPointer[size];
	//Calculate indexes
	Z_INT64    nIndexLevel1 = 0;
	Z_INT64    nIndexLevel2 = 0;
	Z_INT64    nIndexLevel3 = 0;
	if(pMemoryPoolBlock->m_nIndexLevel1 < BITS_NUMBER_PER_INT64 
	&& (pMemoryPoolBlock->m_nBitmapFull4096[pMemoryPoolBlock->m_nIndexLevel1 * 64 + pMemoryPoolBlock->m_nIndexLevel2] & m_int64Bits[pMemoryPoolBlock->m_nIndexLevel3]) == 0)
	{
		nIndexLevel1 = pMemoryPoolBlock->m_nIndexLevel1;
		nIndexLevel2 = pMemoryPoolBlock->m_nIndexLevel2;
		nIndexLevel3 = pMemoryPoolBlock->m_nIndexLevel3;
		pMemoryPoolBlock->m_nIndexLevel3++;
		if(pMemoryPoolBlock->m_nIndexLevel3 >= BITS_NUMBER_PER_INT64) {
			pMemoryPoolBlock->m_nIndexLevel3 = 0;
			pMemoryPoolBlock->m_nIndexLevel2++;
		}
		if(pMemoryPoolBlock->m_nIndexLevel2 >= BITS_NUMBER_PER_INT64) {
			pMemoryPoolBlock->m_nIndexLevel2 = 0;
			pMemoryPoolBlock->m_nIndexLevel1++;
		}
	}
	else
	{
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_poolHead.m_nBitmapFull & m_int64Bits[i]) == 0)
			{
				nIndexLevel1 = i;
				break;
			}
		}
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] & m_int64Bits[i]) == 0)
			{
				nIndexLevel2 = i;
				break;
			}
		}
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] & m_int64Bits[i]) == 0)
			{
				nIndexLevel3 = i;
				break;
			}
		}
	}

	//Update full flag
	pMemoryPoolBlock->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] |= m_int64Bits[nIndexLevel3];
	if(pMemoryPoolBlock->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] == BLOCK_IS_FULL)
	{
		pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] |= m_int64Bits[nIndexLevel2];
		if(pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] == BLOCK_IS_FULL)
		{
			pMemoryPoolBlock->m_poolHead.m_nBitmapFull |= m_int64Bits[nIndexLevel1];
		}
	}
	//Update empty flag
	pMemoryPoolBlock->m_nBitmapEmpty64[nIndexLevel1] |= m_int64Bits[nIndexLevel2];
	pMemoryPoolBlock->m_poolHead.m_nBitmapEmpty |= m_int64Bits[nIndexLevel1];

	//Calculate offset
	Z_INT64    nOffset = ((nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3) * pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal;
	if(m_bQuickMode)
	{
		return (((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	}
	
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	pMemoryUnit->m_pSystemMemoryAddress = pMemoryPoolBlock;
	//Set Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + size;
	* pCheckCodeSuffix = m_chCheckCode;

	return ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER);
}

void *	CZMemoryPool::AllocateFromPoolBlockGigantic(size_t size)
{
	MEMORY_POOL_BLOCK_GIGANTIC *pMemoryPoolBlock = (MEMORY_POOL_BLOCK_GIGANTIC *) m_pPoolPointer[size];
	//Calculate indexes
	Z_INT64    nIndexLevel1 = 0;
	Z_INT64    nIndexLevel2 = 0;
	Z_INT64    nIndexLevel3 = 0;
	Z_INT64    nIndexLevel4 = 0;
	if(pMemoryPoolBlock->m_nIndexLevel1 < BITS_NUMBER_PER_INT64 
	&& (pMemoryPoolBlock->m_nBitmapFull262144[(pMemoryPoolBlock->m_nIndexLevel1 * 64 + pMemoryPoolBlock->m_nIndexLevel2) * 64 + pMemoryPoolBlock->m_nIndexLevel3] & m_int64Bits[pMemoryPoolBlock->m_nIndexLevel4]) == 0)
	{
		nIndexLevel1 = pMemoryPoolBlock->m_nIndexLevel1;
		nIndexLevel2 = pMemoryPoolBlock->m_nIndexLevel2;
		nIndexLevel3 = pMemoryPoolBlock->m_nIndexLevel3;
		nIndexLevel4 = pMemoryPoolBlock->m_nIndexLevel4;
		pMemoryPoolBlock->m_nIndexLevel4++;
		if(pMemoryPoolBlock->m_nIndexLevel4 >= BITS_NUMBER_PER_INT64) {
			pMemoryPoolBlock->m_nIndexLevel4 = 0;
			pMemoryPoolBlock->m_nIndexLevel3++;
		}
		if(pMemoryPoolBlock->m_nIndexLevel3 >= BITS_NUMBER_PER_INT64) {
			pMemoryPoolBlock->m_nIndexLevel3 = 0;
			pMemoryPoolBlock->m_nIndexLevel2++;
		}
		if(pMemoryPoolBlock->m_nIndexLevel2 >= BITS_NUMBER_PER_INT64) {
			pMemoryPoolBlock->m_nIndexLevel2 = 0;
			pMemoryPoolBlock->m_nIndexLevel1++;
		}
	}
	else
	{
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_poolHead.m_nBitmapFull & m_int64Bits[i]) == 0)
			{
				nIndexLevel1 = i;
				break;
			}
		}
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] & m_int64Bits[i]) == 0)
			{
				nIndexLevel2 = i;
				break;
			}
		}
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] & m_int64Bits[i]) == 0)
			{
				nIndexLevel3 = i;
				break;
			}
		}
		for(int i = 0; i < BITS_NUMBER_PER_INT64; i++)
		{
			if((pMemoryPoolBlock->m_nBitmapFull262144[(nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3] & m_int64Bits[i]) == 0)
			{
				nIndexLevel4 = i;
				break;
			}
		}
	}

	//Update full flag
	pMemoryPoolBlock->m_nBitmapFull262144[(nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3] |= m_int64Bits[nIndexLevel4];
	if(pMemoryPoolBlock->m_nBitmapFull262144[(nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3] == BLOCK_IS_FULL)
	{
		pMemoryPoolBlock->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] |= m_int64Bits[nIndexLevel3];
		if(pMemoryPoolBlock->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] == BLOCK_IS_FULL)
		{
			pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] |= m_int64Bits[nIndexLevel2];
			if(pMemoryPoolBlock->m_nBitmapFull64[nIndexLevel1] == BLOCK_IS_FULL)
			{
				pMemoryPoolBlock->m_poolHead.m_nBitmapFull |= m_int64Bits[nIndexLevel1];
			}
		}
	}	
	//Update empty flag
	pMemoryPoolBlock->m_nBitmapEmpty4096[nIndexLevel1 * 64 + nIndexLevel2] |= m_int64Bits[nIndexLevel3];
	pMemoryPoolBlock->m_nBitmapEmpty64[nIndexLevel1] |= m_int64Bits[nIndexLevel2];
	pMemoryPoolBlock->m_poolHead.m_nBitmapEmpty |= m_int64Bits[nIndexLevel1];

	//Calculate offset
	Z_INT64    nOffset = (((nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3) * 64 + nIndexLevel4) * pMemoryPoolBlock->m_poolHead.m_nUnitSizeReal;
	if(m_bQuickMode)
	{
		return (((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	}
	
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)pMemoryPoolBlock->m_poolHead.m_pMemoryPoolAddress) + nOffset);
	pMemoryUnit->m_pSystemMemoryAddress = pMemoryPoolBlock;
	//Set Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + size;
	* pCheckCodeSuffix = m_chCheckCode;

	return ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER);
}


void *	CZMemoryPool::AllocateFromPoolBlock(size_t size)
{
	if(((MEMORY_POOL_BLOCK_SMALL *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_SMALL)
	{
		return AllocateFromPoolBlockSmall(size);
	}
	else if(((MEMORY_POOL_BLOCK_MEDIUM *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_MEDIUM)
	{
		return AllocateFromPoolBlockMedium(size);
	}
	else if(((MEMORY_POOL_BLOCK_HUGE *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_HUGE)
	{
		return AllocateFromPoolBlockHuge(size);
	}
	else if(((MEMORY_POOL_BLOCK_GIGANTIC *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_GIGANTIC)
	{
		return AllocateFromPoolBlockGigantic(size);
	}
	else
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: Invalid Memory Pool Type!");
		return NULL;
	}
}



void * CZMemoryPool::Malloc(size_t size)
{
	//allocate from system directly
	//To avoid allocating m_pPoolPointer and m_pPoolCounter, the first 10 memory will be allocated from system without initializing m_pPoolPointer and m_pPoolCounter
	if(m_nTotalAllocatedCount++ < THRESHOLD_COUNT_RAW_MALLOC)
	{
		void * ptr = MallocFromSystem(size);
		return ptr;
	}
	//Will not allocate from memory pool when the size is greater than 1024
	if(size >= MEMORY_POOL_NUMBER)
	{
		return MallocFromSystem(size);
	}
	
	//Allocate m_pPoolPointer and m_pPoolCounter if not initialized
	if(m_pPoolPointer == NULL)
	{
		m_pPoolPointer = (void **)malloc(sizeof(void *) * MEMORY_POOL_NUMBER);
		memset(m_pPoolPointer, 0X00, sizeof(void *) * MEMORY_POOL_NUMBER);
	}
	if(m_pPoolCounter == NULL)
	{
		m_pPoolCounter = (Z_INT64 *)malloc(sizeof(Z_INT64) * MEMORY_POOL_NUMBER);
		memset(m_pPoolCounter, 0X00, sizeof(Z_INT64) * MEMORY_POOL_NUMBER);
	}
	
	//increment m_pPoolCounter[size] as a constraint to use small, medium or huge block
	m_pPoolCounter[size]++;
	
	// allocate from system directly
	if(m_pPoolCounter[size] <= THRESHOLD_COUNT_RAW_MALLOC)
	{
		return MallocFromSystem(size);
	}
	
	//If m_pPoolPointer[size] is full, just remove it from m_pPoolPointer
	while(m_pPoolPointer[size] != NULL)
	{
		if(((MEMORY_POOL_BLOCK_SMALL *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_SMALL)
		{
			if((((MEMORY_POOL_BLOCK_SMALL *)m_pPoolPointer[size])->m_poolHead.m_nBitmapFull == BLOCK_IS_FULL))
			{
				m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &(m_pPoolPointer[size]), sizeof(void *), FALSE);
				
				MEMORY_POOL_BLOCK_SMALL * pParent = (MEMORY_POOL_BLOCK_SMALL *)m_pPoolPointer[size];
				m_pPoolPointer[size] = pParent->m_poolHead.m_pNextBlock;
				pParent->m_poolHead.m_pNextBlock = NULL;
			}
			else
			{
				break;
			}
		}
		else if(((MEMORY_POOL_BLOCK_MEDIUM *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_MEDIUM)
		{
			if((((MEMORY_POOL_BLOCK_MEDIUM *)m_pPoolPointer[size])->m_poolHead.m_nBitmapFull == BLOCK_IS_FULL))
			{
				m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &(m_pPoolPointer[size]), sizeof(void *), FALSE);
				
				MEMORY_POOL_BLOCK_MEDIUM * pParent = (MEMORY_POOL_BLOCK_MEDIUM *)m_pPoolPointer[size];
				m_pPoolPointer[size] = pParent->m_poolHead.m_pNextBlock;
				pParent->m_poolHead.m_pNextBlock = NULL;
			}
			else
			{
				break;
			}
		}
		else if(((MEMORY_POOL_BLOCK_HUGE *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_HUGE)
		{
			if((((MEMORY_POOL_BLOCK_HUGE *)m_pPoolPointer[size])->m_poolHead.m_nBitmapFull == BLOCK_IS_FULL))
			{
				m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &(m_pPoolPointer[size]), sizeof(void *), FALSE);
				
				MEMORY_POOL_BLOCK_HUGE * pParent = (MEMORY_POOL_BLOCK_HUGE *)m_pPoolPointer[size];
				m_pPoolPointer[size] = pParent->m_poolHead.m_pNextBlock;
				pParent->m_poolHead.m_pNextBlock = NULL;
			}
			else
			{
				break;
			}
		}
		else if(((MEMORY_POOL_BLOCK_GIGANTIC *) m_pPoolPointer[size])->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_GIGANTIC)
		{
			if((((MEMORY_POOL_BLOCK_GIGANTIC *)m_pPoolPointer[size])->m_poolHead.m_nBitmapFull == BLOCK_IS_FULL))
			{
				m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &(m_pPoolPointer[size]), sizeof(void *), FALSE);
				
				MEMORY_POOL_BLOCK_GIGANTIC * pParent = (MEMORY_POOL_BLOCK_GIGANTIC *)m_pPoolPointer[size];
				m_pPoolPointer[size] = pParent->m_poolHead.m_pNextBlock;
				pParent->m_poolHead.m_pNextBlock = NULL;
			}
			else
			{
				break;
			}
		}
		else
		{
			CZErrorProcessorBase::ProcessError("Memory Pool: Invalid m_nBlockFlag");
			return NULL;
		}
	}
	
	//Allocate m_pPoolPointer[size]
	if(m_pPoolPointer[size] == NULL)
	{
		if(!CreateMomeryPoolBlock(size))
		{
			CZErrorProcessorBase::ProcessError("Memory Pool: Create Momery Pool Block error!");
			return NULL;
		}
	}
	if(m_pPoolPointer[size] == NULL)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: Create Momery Pool Block error!");
		return NULL;
	}
	
	return AllocateFromPoolBlock(size);
}




//Free memoy from pool block
BOOL	CZMemoryPool::RemovePoolFromList(unsigned Z_INT64 p_nUnitSizeRequested, void * p_pMemoryPool)
{
	if(m_pPoolPointer[p_nUnitSizeRequested] == p_pMemoryPool)
	{
		MEMORY_POOL_BLOCK_SMALL * pParent = (MEMORY_POOL_BLOCK_SMALL * )p_pMemoryPool;
		if(pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_SMALL 
		&& pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_MEDIUM 
		&& pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_HUGE
		&& pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_GIGANTIC)
		{
			CZErrorProcessorBase::ProcessError("Memory Pool: Can't mix MEMORY_POOL_BLOCK_SMALL, MEMORY_POOL_BLOCK_MEDIUM and MEMORY_POOL_BLOCK_HUGE.");
		}
		m_pPoolPointer[p_nUnitSizeRequested] = pParent->m_poolHead.m_pNextBlock;
		return TRUE;
	}
	else
	{
		MEMORY_POOL_BLOCK_SMALL * pParent = (MEMORY_POOL_BLOCK_SMALL *)(m_pPoolPointer[p_nUnitSizeRequested]);
		while(pParent->m_poolHead.m_pNextBlock != p_pMemoryPool && pParent->m_poolHead.m_pNextBlock != NULL)
		{
			pParent = (MEMORY_POOL_BLOCK_SMALL *)(pParent->m_poolHead.m_pNextBlock);
			if(pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_SMALL 
			&& pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_MEDIUM 
			&& pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_HUGE
			&& pParent->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_GIGANTIC)
			{
				CZErrorProcessorBase::ProcessError("Memory Pool: Can't mix MEMORY_POOL_BLOCK_SMALL, MEMORY_POOL_BLOCK_MEDIUM and MEMORY_POOL_BLOCK_HUGE.");
			}
		}
		if(pParent->m_poolHead.m_pNextBlock == p_pMemoryPool)
		{
			if(((MEMORY_POOL_BLOCK_SMALL * )p_pMemoryPool)->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_SMALL 
			&& ((MEMORY_POOL_BLOCK_SMALL * )p_pMemoryPool)->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_MEDIUM 
			&& ((MEMORY_POOL_BLOCK_SMALL * )p_pMemoryPool)->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_HUGE
			&& ((MEMORY_POOL_BLOCK_SMALL * )p_pMemoryPool)->m_poolHead.m_nBlockFlag != THRESHOLD_COUNT_BLOCK_GIGANTIC)
			{
				CZErrorProcessorBase::ProcessError("Memory Pool: Can't mix MEMORY_POOL_BLOCK_SMALL, MEMORY_POOL_BLOCK_MEDIUM and MEMORY_POOL_BLOCK_HUGE.");
			}
			pParent->m_poolHead.m_pNextBlock = ((MEMORY_POOL_BLOCK_SMALL * )p_pMemoryPool)->m_poolHead.m_pNextBlock;
			return TRUE;
		}
	}
	CZErrorProcessorBase::ProcessError("Memory Pool: Remove Pool From List failed.");
	return FALSE;
}

BOOL	CZMemoryPool::FreeFromPoolBlockSmall(MEMORY_POOL_BLOCK_SMALL * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty)
{
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)ptr) - sizeof(MEMORY_UNIT_HEADER));
	//Check Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + p_pMemoryPool->m_poolHead.m_nUnitSizeRequested;
	if(* pCheckCodeSuffix != m_chCheckCode)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The check code of the memory allocated from pool is wrong. There may be buffer overflow.");
	}
		
	//Calculate indexes
	Z_INT64 nOffset = (((unsigned char *)pMemoryUnit) - ((unsigned char *)(p_pMemoryPool->m_poolHead.m_pMemoryPoolAddress))) / p_pMemoryPool->m_poolHead.m_nUnitSizeReal;
	Z_INT64 nIndexLevel1 = nOffset % 64;
	
	//Set full and empty flags
	if(!(p_pMemoryPool->m_poolHead.m_nBitmapFull & m_int64Bits[nIndexLevel1]))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The memory was not allocated from pool or the memory has already been freed.");
	}
	else
	{
		if(0 <= p_pMemoryPool->m_poolHead.m_nUnitSizeRequested && p_pMemoryPool->m_poolHead.m_nUnitSizeRequested < MEMORY_POOL_NUMBER && m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] > 0)
		{
			m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]--;
		}
	}
	p_pMemoryPool->m_poolHead.m_nBitmapFull &= ~m_int64Bits[nIndexLevel1];
	p_pMemoryPool->m_poolHead.m_nBitmapEmpty &= ~m_int64Bits[nIndexLevel1];
	
	//If this block is not empty, add it to Pool List and return
	if(p_pMemoryPool->m_poolHead.m_nBitmapEmpty != BLOCK_IS_EMPTY)
	{
		if(!m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
		{
			m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), p_pMemoryPool);
			
			if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == NULL)
			{
				m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] = p_pMemoryPool;
				p_pMemoryPool->m_poolHead.m_pNextBlock = NULL;
			}
			else //Add it after m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]
			{
				p_pMemoryPool->m_poolHead.m_pNextBlock = ((MEMORY_POOL_BLOCK_SMALL * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock;
				((MEMORY_POOL_BLOCK_SMALL * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock = p_pMemoryPool;
				
			}
		}
		return TRUE;
	}
	
	//If this node is empty and this is the only node in m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested], don't free it.
	if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == p_pMemoryPool && p_pMemoryPool->m_poolHead.m_pNextBlock == NULL)
	{
		return TRUE;
	}
	
	//if this node is empty and this node exists in m_objMemoryZTreeInList(m_pPoolPointer), we need to remove it from m_objMemoryZTreeInList(m_pPoolPointer)
	if(m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
	{
		RemovePoolFromList(p_pMemoryPool->m_poolHead.m_nUnitSizeRequested, p_pMemoryPool);
		m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), FALSE);
	}
	
	//Since this node is empty and removed from list, remove it from m_objMemoryZTreeAll and m_objMemoryZTreeAll will free the memory Pool.
	m_objMemoryZTreeAll.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), TRUE);
	
	return TRUE;
}
BOOL	CZMemoryPool::FreeFromPoolBlockMedium(MEMORY_POOL_BLOCK_MEDIUM * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty)
{
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)ptr) - sizeof(MEMORY_UNIT_HEADER));
	//Check Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + p_pMemoryPool->m_poolHead.m_nUnitSizeRequested;
	if(* pCheckCodeSuffix != m_chCheckCode)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The check code of the memory allocated from pool is wrong. There may be buffer overflow.");
	}
		
	//Calculate indexes
	Z_INT64 nOffset = (((unsigned char *)pMemoryUnit) - ((unsigned char *)(p_pMemoryPool->m_poolHead.m_pMemoryPoolAddress))) / p_pMemoryPool->m_poolHead.m_nUnitSizeReal;
	Z_INT64 nIndexLevel2 = nOffset % 64;
	nOffset =  nOffset / 64;
	Z_INT64 nIndexLevel1 = nOffset % 64;
	
	//Set full and empty flags
	if(!(p_pMemoryPool->m_nBitmapFull64[nIndexLevel1] & m_int64Bits[nIndexLevel2]))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The memory was not allocated from pool or the memory has already been freed.");
	}
	else
	{
		if(0 <= p_pMemoryPool->m_poolHead.m_nUnitSizeRequested && p_pMemoryPool->m_poolHead.m_nUnitSizeRequested < MEMORY_POOL_NUMBER && m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] > 0)
		{
			m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]--;
		}
	}
	p_pMemoryPool->m_nBitmapFull64[nIndexLevel1] &= ~m_int64Bits[nIndexLevel2];
	p_pMemoryPool->m_poolHead.m_nBitmapFull &= ~m_int64Bits[nIndexLevel1];
	if(p_pMemoryPool->m_nBitmapFull64[nIndexLevel1] == BLOCK_IS_EMPTY)
	{
		p_pMemoryPool->m_poolHead.m_nBitmapEmpty &= ~m_int64Bits[nIndexLevel1];
	}
	
	//If this block is not empty, add it to Pool List and return
	if(p_pMemoryPool->m_poolHead.m_nBitmapEmpty != BLOCK_IS_EMPTY)
	{
		if(!m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
		{
			m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), p_pMemoryPool);
			
			if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == NULL)
			{
				m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] = p_pMemoryPool;
				p_pMemoryPool->m_poolHead.m_pNextBlock = NULL;
			}
			else //Add it after m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]
			{
				p_pMemoryPool->m_poolHead.m_pNextBlock = ((MEMORY_POOL_BLOCK_MEDIUM * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock;
				((MEMORY_POOL_BLOCK_SMALL * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock = p_pMemoryPool;
				
			}
		}
		return TRUE;
	}
	
	//If this node is empty and this is the only node in m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested], don't free it.
	if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == p_pMemoryPool && p_pMemoryPool->m_poolHead.m_pNextBlock == NULL)
	{
		return TRUE;
	}
	
	//if this node is empty and this node exists in m_objMemoryZTreeInList(m_pPoolPointer), we need to remove it from m_objMemoryZTreeInList(m_pPoolPointer)
	if(m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
	{
		RemovePoolFromList(p_pMemoryPool->m_poolHead.m_nUnitSizeRequested, p_pMemoryPool);
		m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), FALSE);
	}
	
	//Since this node is empty and removed from list, remove it from m_objMemoryZTreeAll and m_objMemoryZTreeAll will free the memory Pool.
	m_objMemoryZTreeAll.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), TRUE);
	
	return TRUE;
}
BOOL	CZMemoryPool::FreeFromPoolBlockHuge(MEMORY_POOL_BLOCK_HUGE * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty)
{
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)ptr) - sizeof(MEMORY_UNIT_HEADER));
	//Check Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + p_pMemoryPool->m_poolHead.m_nUnitSizeRequested;
	if(* pCheckCodeSuffix != m_chCheckCode)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The check code of the memory allocated from pool is wrong. There may be buffer overflow.");
	}
		
	//Calculate indexes
	Z_INT64 nOffset = (((unsigned char *)pMemoryUnit) - ((unsigned char *)(p_pMemoryPool->m_poolHead.m_pMemoryPoolAddress))) / p_pMemoryPool->m_poolHead.m_nUnitSizeReal;
	Z_INT64 nIndexLevel3 = nOffset % 64;
	nOffset =  nOffset / 64;
	Z_INT64 nIndexLevel2 = nOffset % 64;
	nOffset =  nOffset / 64;
	Z_INT64 nIndexLevel1 = nOffset % 64;
	
	//Set full and empty flags
	if(!(p_pMemoryPool->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] & m_int64Bits[nIndexLevel3]))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The memory was not allocated from pool or the memory has already been freed.");
	}
	else
	{
		if(0 <= p_pMemoryPool->m_poolHead.m_nUnitSizeRequested && p_pMemoryPool->m_poolHead.m_nUnitSizeRequested < MEMORY_POOL_NUMBER && m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] > 0)
		{
			m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]--;
		}
	}
	p_pMemoryPool->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] &= ~m_int64Bits[nIndexLevel3];
	p_pMemoryPool->m_nBitmapFull64[nIndexLevel1] &= ~m_int64Bits[nIndexLevel2];
	p_pMemoryPool->m_poolHead.m_nBitmapFull &= ~m_int64Bits[nIndexLevel1];
	if(p_pMemoryPool->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] == BLOCK_IS_EMPTY)
	{
		p_pMemoryPool->m_nBitmapEmpty64[nIndexLevel1] &= ~m_int64Bits[nIndexLevel2];
		if(p_pMemoryPool->m_nBitmapEmpty64[nIndexLevel1] == BLOCK_IS_EMPTY)
		{
			p_pMemoryPool->m_poolHead.m_nBitmapEmpty &= ~m_int64Bits[nIndexLevel1];
		}
	}
	
	//If this block is not empty, add it to Pool List and return
	if(p_pMemoryPool->m_poolHead.m_nBitmapEmpty != BLOCK_IS_EMPTY)
	{
		if(!m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
		{
			m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), p_pMemoryPool);
			
			if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == NULL)
			{
				m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] = p_pMemoryPool;
				p_pMemoryPool->m_poolHead.m_pNextBlock = NULL;
			}
			else //Add it after m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]
			{
				p_pMemoryPool->m_poolHead.m_pNextBlock = ((MEMORY_POOL_BLOCK_HUGE * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock;
				((MEMORY_POOL_BLOCK_SMALL * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock = p_pMemoryPool;
				
			}
		}
		return TRUE;
	}
	
	//If this node is empty and this is the only node in m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested], don't free it.
	if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == p_pMemoryPool && p_pMemoryPool->m_poolHead.m_pNextBlock == NULL)
	{
		return TRUE;
	}
	
	//if this node is empty and this node exists in m_objMemoryZTreeInList(m_pPoolPointer), we need to remove it from m_objMemoryZTreeInList(m_pPoolPointer)
	if(m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
	{
		RemovePoolFromList(p_pMemoryPool->m_poolHead.m_nUnitSizeRequested, p_pMemoryPool);
		m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), FALSE);
	}
	
	//Since this node is empty and removed from list, remove it from m_objMemoryZTreeAll and m_objMemoryZTreeAll will free the memory Pool.
	m_objMemoryZTreeAll.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), TRUE);
	
	return TRUE;
}

BOOL	CZMemoryPool::FreeFromPoolBlockGigantic(MEMORY_POOL_BLOCK_GIGANTIC * p_pMemoryPool, void* ptr, BOOL p_bIsInList, BOOL & p_bIsEmpty)
{
	MEMORY_UNIT_HEADER * pMemoryUnit = (MEMORY_UNIT_HEADER *)(((unsigned char *)ptr) - sizeof(MEMORY_UNIT_HEADER));
	//Check Check Code at the end of the memory
	unsigned char * pCheckCodeSuffix = ((unsigned char *)pMemoryUnit) + sizeof(MEMORY_UNIT_HEADER) + p_pMemoryPool->m_poolHead.m_nUnitSizeRequested;
	if(* pCheckCodeSuffix != m_chCheckCode)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The check code of the memory allocated from pool is wrong. There may be buffer overflow.");
	}
		
	//Calculate indexes
	Z_INT64 nOffset = (((unsigned char *)pMemoryUnit) - ((unsigned char *)(p_pMemoryPool->m_poolHead.m_pMemoryPoolAddress))) / p_pMemoryPool->m_poolHead.m_nUnitSizeReal;
	Z_INT64 nIndexLevel4 = nOffset % 64;
	nOffset =  nOffset / 64;
	Z_INT64 nIndexLevel3 = nOffset % 64;
	nOffset =  nOffset / 64;
	Z_INT64 nIndexLevel2 = nOffset % 64;
	nOffset =  nOffset / 64;
	Z_INT64 nIndexLevel1 = nOffset % 64;
	
	//Set full and empty flags
	if(!(p_pMemoryPool->m_nBitmapFull262144[(nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3] & m_int64Bits[nIndexLevel4]))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The memory was not allocated from pool or the memory has already been freed.");
	}
	else
	{
		if(0 <= p_pMemoryPool->m_poolHead.m_nUnitSizeRequested && p_pMemoryPool->m_poolHead.m_nUnitSizeRequested < MEMORY_POOL_NUMBER && m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] > 0)
		{
			m_pPoolCounter[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]--;
		}
	}
	p_pMemoryPool->m_nBitmapFull262144[(nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3] &= ~m_int64Bits[nIndexLevel4];
	p_pMemoryPool->m_nBitmapFull4096[nIndexLevel1 * 64 + nIndexLevel2] &= ~m_int64Bits[nIndexLevel3];
	p_pMemoryPool->m_nBitmapFull64[nIndexLevel1] &= ~m_int64Bits[nIndexLevel2];
	p_pMemoryPool->m_poolHead.m_nBitmapFull &= ~m_int64Bits[nIndexLevel1];
	if(p_pMemoryPool->m_nBitmapFull262144[(nIndexLevel1 * 64 + nIndexLevel2) * 64 + nIndexLevel3] == BLOCK_IS_EMPTY)
	{
		p_pMemoryPool->m_nBitmapEmpty4096[nIndexLevel1 * 64 + nIndexLevel2] &= ~m_int64Bits[nIndexLevel3];
		if(p_pMemoryPool->m_nBitmapEmpty4096[nIndexLevel1 * 64 + nIndexLevel2] == BLOCK_IS_EMPTY)
		{
			p_pMemoryPool->m_nBitmapEmpty64[nIndexLevel1] &= ~m_int64Bits[nIndexLevel2];
			if(p_pMemoryPool->m_nBitmapEmpty64[nIndexLevel1] == BLOCK_IS_EMPTY)
			{
				p_pMemoryPool->m_poolHead.m_nBitmapEmpty &= ~m_int64Bits[nIndexLevel1];
			}
		}
	}
	
	//If this block is not empty, add it to Pool List and return
	if(p_pMemoryPool->m_poolHead.m_nBitmapEmpty != BLOCK_IS_EMPTY)
	{
		if(!m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
		{
			m_objMemoryZTreeInList.AddKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), p_pMemoryPool);
			
			if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == NULL)
			{
				m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] = p_pMemoryPool;
				p_pMemoryPool->m_poolHead.m_pNextBlock = NULL;
			}
			else //Add it after m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested]
			{
				p_pMemoryPool->m_poolHead.m_pNextBlock = ((MEMORY_POOL_BLOCK_GIGANTIC * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock;
				((MEMORY_POOL_BLOCK_SMALL * )m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested])->m_poolHead.m_pNextBlock = p_pMemoryPool;
				
			}
		}
		return TRUE;
	}
	
	//If this node is empty and this is the only node in m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested], don't free it.
	if(m_pPoolPointer[p_pMemoryPool->m_poolHead.m_nUnitSizeRequested] == p_pMemoryPool && p_pMemoryPool->m_poolHead.m_pNextBlock == NULL)
	{
		return TRUE;
	}
	
	//if this node is empty and this node exists in m_objMemoryZTreeInList(m_pPoolPointer), we need to remove it from m_objMemoryZTreeInList(m_pPoolPointer)
	if(m_objMemoryZTreeInList.GetValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool)))
	{
		RemovePoolFromList(p_pMemoryPool->m_poolHead.m_nUnitSizeRequested, p_pMemoryPool);
		m_objMemoryZTreeInList.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), FALSE);
	}
	
	//Since this node is empty and removed from list, remove it from m_objMemoryZTreeAll and m_objMemoryZTreeAll will free the memory Pool.
	m_objMemoryZTreeAll.RemoveKeyValue((unsigned char *) &p_pMemoryPool, sizeof(p_pMemoryPool), TRUE);
	
	return TRUE;
}


void CZMemoryPool::Free(void* ptr)
{
	if(ptr == NULL)
	{
		return;
	}
	//While running in quick mode, the function Free() doesn't work at all.
	if(m_bQuickMode)
	{
		return;
	}
	
	unsigned char * pRequestedAddress = (unsigned char * )ptr;
	MEMORY_UNIT_HEADER * pMemoryUnitHeader = (MEMORY_UNIT_HEADER *)(pRequestedAddress - (sizeof(MEMORY_UNIT_HEADER)));
	void * pSystemMemoryAddress = pMemoryUnitHeader->m_pSystemMemoryAddress;
	
	//Free Raw Memory
	if(pRequestedAddress - ((unsigned char *)pSystemMemoryAddress) < sizeof(MEMORY_POOL_BLOCK_SMALL))
	{
		//Check Check Code at the end of the memory
		RAW_MEMORY_HEADER * pRawMemoryHeader = (RAW_MEMORY_HEADER *)(pRequestedAddress - (sizeof(RAW_MEMORY_HEADER) + sizeof(MEMORY_UNIT_HEADER)));
		unsigned char * pCheckCodeSuffix = ((unsigned char *)pSystemMemoryAddress) + (sizeof(RAW_MEMORY_HEADER) + sizeof(MEMORY_UNIT_HEADER)) + pRawMemoryHeader->m_nMemorySizeRequested;
		if(* pCheckCodeSuffix != m_chCheckCode)
		{
			CZErrorProcessorBase::ProcessError("Memory Pool: The check code of memory allocated from system is wrong. The memory is not allocated from system or it was freed twice or there was buffer overflow.");
		}
		
		unsigned Z_INT64				nMemorySizeRequested = pRawMemoryHeader->m_nMemorySizeRequested;
		if(!m_objMemoryZTreeAll.RemoveKeyValue((unsigned char *) &pSystemMemoryAddress, sizeof(pSystemMemoryAddress), TRUE))
		{
			CZErrorProcessorBase::ProcessError("Memory Pool: The memory allocated from system doesn't exist. The memory is not allocated from system or it was freed twice or there was buffer overflow.");
		}
		else
		{
			if(0 <= nMemorySizeRequested && nMemorySizeRequested < MEMORY_POOL_NUMBER && (m_pPoolCounter != NULL) && m_pPoolCounter[nMemorySizeRequested] > 0)
			{
				m_pPoolCounter[nMemorySizeRequested]--;
			}
		}
		return;
	}
	
	//Free Memory in Pool
	BOOL bIsInList = (m_objMemoryZTreeAll.GetValue((unsigned char *) &pSystemMemoryAddress, sizeof(pSystemMemoryAddress)) ? TRUE : FALSE);
	if(!bIsInList)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The memory pool doesn't exist. The memory is not allocated from pool or it was freed twice or there was buffer overflow.");
		return;
	}
	BOOL bIsEmptyAfterFree = FALSE;
	if(((MEMORY_POOL_BLOCK_SMALL *) pSystemMemoryAddress)->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_SMALL)
	{
		FreeFromPoolBlockSmall((MEMORY_POOL_BLOCK_SMALL *) pSystemMemoryAddress, ptr, bIsInList, bIsEmptyAfterFree);
	}
	else if(((MEMORY_POOL_BLOCK_MEDIUM *) pSystemMemoryAddress)->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_MEDIUM)
	{
		FreeFromPoolBlockMedium((MEMORY_POOL_BLOCK_MEDIUM *) pSystemMemoryAddress, ptr, bIsInList, bIsEmptyAfterFree);
	}
	else if(((MEMORY_POOL_BLOCK_HUGE *) pSystemMemoryAddress)->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_HUGE)
	{
		FreeFromPoolBlockHuge((MEMORY_POOL_BLOCK_HUGE *) pSystemMemoryAddress, ptr, bIsInList, bIsEmptyAfterFree);
	}
	else if(((MEMORY_POOL_BLOCK_GIGANTIC *) pSystemMemoryAddress)->m_poolHead.m_nBlockFlag == THRESHOLD_COUNT_BLOCK_GIGANTIC)
	{
		FreeFromPoolBlockGigantic((MEMORY_POOL_BLOCK_GIGANTIC *) pSystemMemoryAddress, ptr, bIsInList, bIsEmptyAfterFree);
	}
	else
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: Free: Invalid Memory Pool Type! Fail to free.");
	}
}

//The object must based on CObject
//Return pObject. Creating an object can be defined as below:
//CXXXX * pNewObject = (CXXXX *) memoryPool.AddObject(new CXXXX);
void * CZMemoryPool::AddObject(void * pObject)
{
	if(pObject == NULL)
	{
		return NULL;
	}
	BOOL bIsInList = (m_objMemoryZTreeForCPPObjects.GetValue((unsigned char *) &pObject, sizeof(pObject)) ? TRUE : FALSE);
	if(bIsInList)
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The object already exists in the memory pool!");
		return pObject;
	}
	if(!m_objMemoryZTreeForCPPObjects.AddKeyValue((unsigned char *) &pObject, sizeof(pObject), pObject))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: AddObject fail to add object to hash table! ");
	}
	return pObject;
}

//The object must based on CObject
BOOL CZMemoryPool::DeleteObject(void * pObject)
{
	if(pObject == NULL)
	{
		return TRUE;
	}
	if(!m_objMemoryZTreeForCPPObjects.RemoveKeyValue((unsigned char *) &pObject, sizeof(pObject), TRUE))
	{
		CZErrorProcessorBase::ProcessError("Memory Pool: The object to delete doesn't exist. The object was not added to memory pool or has already been deleted.");
		return FALSE;
	}
	return TRUE;
}