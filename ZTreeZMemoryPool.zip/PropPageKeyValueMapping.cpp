// PropPageKeyValueMapping.cpp : implementation file
//

#include "stdafx.h"
#include "ZTreeZMemoryPool.h"
#include "PropPageKeyValueMapping.h"


// CPropPageKeyValueMapping dialog

IMPLEMENT_DYNAMIC(CPropPageKeyValueMapping, CPropertyPage)

CPropPageKeyValueMapping::CPropPageKeyValueMapping()
	: CPropertyPage(CPropPageKeyValueMapping::IDD)
{

}

CPropPageKeyValueMapping::~CPropPageKeyValueMapping()
{
}

void CPropPageKeyValueMapping::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPropPageKeyValueMapping, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_KEY_VALUE_MAPPING_ONE_TO_ONE, &CPropPageKeyValueMapping::OnBnClickedBtnKeyValueMappingOneToOne)
	ON_BN_CLICKED(IDC_BTN_KEY_VALUE_MAPPING_ONE_TO_MANY, &CPropPageKeyValueMapping::OnBnClickedBtnKeyValueMappingOneToMany)
END_MESSAGE_MAP()


// CPropPageKeyValueMapping message handlers

void CPropPageKeyValueMapping::OnBnClickedBtnKeyValueMappingOneToOne()
{
	// TODO: Add your control notification handler code here
	CZMemoryPool memoryPool;
	CZTreeOneValue ztreeOneValue;
	ztreeOneValue.InitZTree();

	int BUFF_SIZE = 10;
	TCHAR wszKey[10];
	//pValue will be allocated from memoryPool
	TCHAR * pwszValue; 

	//Create 10000000 key-value and put them into ztreeOneValue
	for(int i = 0; i < 10000000; i++)
	{
		//Z-Tree will allocate memory space for key but only save the address of value. 
		//Hence we need and only need to allocate memory space for value.
		_snwprintf_s(wszKey, BUFF_SIZE, BUFF_SIZE, _T("%d"), i);
		pwszValue = (TCHAR *)memoryPool.Malloc(sizeof(TCHAR) * BUFF_SIZE);
		_snwprintf_s(pwszValue, BUFF_SIZE, BUFF_SIZE, _T("%d"), i);

		ztreeOneValue.AddKeyValue((unsigned char *)wszKey, wcslen(wszKey) * sizeof(TCHAR), pwszValue);
	}

	//Test Case: get value by key
	_snwprintf_s(wszKey, BUFF_SIZE, BUFF_SIZE, _T("%d"), 2016000);
	pwszValue = (TCHAR *) ztreeOneValue.GetValueByKey((unsigned char *)wszKey, (wcslen(wszKey) * 2));
	MessageBox(pwszValue);
}

void CPropPageKeyValueMapping::OnBnClickedBtnKeyValueMappingOneToMany()
{
	// TODO: Add your control notification handler code here
	CZMemoryPool memoryPool;
	CZTreeValueList ztreeValueList;
	ztreeValueList.InitZTree();

	int BUFF_SIZE = 10;
	TCHAR wszKey[10];
	//pValue will be allocated from memoryPool
	TCHAR * pwszValue; 

	//Create 10000000 key-value and put them into ztreeValueList
	for(int i = 0; i < 10000000; i++)
	{
		//Z-Tree will allocate memory space for key but only save the address of value. 
		//Hence we need and only need to allocate memory space for value.
		_snwprintf_s(wszKey, BUFF_SIZE, BUFF_SIZE, _T("%d"), i);
		pwszValue = (TCHAR *)memoryPool.Malloc(sizeof(TCHAR) * BUFF_SIZE);
		_snwprintf_s(pwszValue, BUFF_SIZE, BUFF_SIZE, _T("%d"), i);

		ztreeValueList.AddKeyValue((unsigned char *)wszKey, wcslen(wszKey) * sizeof(TCHAR), pwszValue);
	}

	//Add more values to key "2016000"
	pwszValue = (TCHAR *)memoryPool.Malloc(sizeof(TCHAR) * BUFF_SIZE);
	_snwprintf_s(pwszValue, BUFF_SIZE, BUFF_SIZE, _T("test"));
	ztreeValueList.AddKeyValue((unsigned char *)_T("2016000"), wcslen(_T("2016000")) * sizeof(TCHAR), pwszValue);

	pwszValue = (TCHAR *)memoryPool.Malloc(sizeof(TCHAR) * BUFF_SIZE);
	_snwprintf_s(pwszValue, BUFF_SIZE, BUFF_SIZE, _T("Z-Tree"));
	ztreeValueList.AddKeyValue((unsigned char *)_T("2016000"), wcslen(_T("2016000")) * sizeof(TCHAR), pwszValue);

	pwszValue = (TCHAR *)memoryPool.Malloc(sizeof(TCHAR) * BUFF_SIZE);
	_snwprintf_s(pwszValue, BUFF_SIZE, BUFF_SIZE, _T("Mapping"));
	ztreeValueList.AddKeyValue((unsigned char *)_T("2016000"), wcslen(_T("2016000")) * sizeof(TCHAR), pwszValue);

	pwszValue = (TCHAR *)memoryPool.Malloc(sizeof(TCHAR) * BUFF_SIZE);
	_snwprintf_s(pwszValue, BUFF_SIZE, BUFF_SIZE, _T("Pool"));
	ztreeValueList.AddKeyValue((unsigned char *)_T("2016000"), wcslen(_T("2016000")) * sizeof(TCHAR), pwszValue);

	//Traverse Z-Tree Value List
	_snwprintf_s(wszKey, BUFF_SIZE, BUFF_SIZE, _T("%d"), 2016000);
	ZTREE_VALUE_HEAD * pHead = ztreeValueList.GetValueListByKey((unsigned char *)wszKey, (wcslen(wszKey) * 2));
	ZTREE_VALUE * pZTREE_VALUE = & pHead->m_ZTREE_VALUE;
	while(pZTREE_VALUE != NULL)
	{
		unsigned int	nValueIndex = 0;
		while(nValueIndex < ZTREE_VALUE_ARRAY_SIZE && pZTREE_VALUE->m_pValues[nValueIndex] != NULL)
		{
			MessageBox((TCHAR *)pZTREE_VALUE->m_pValues[nValueIndex]);
			nValueIndex++;
		}
		pZTREE_VALUE = pZTREE_VALUE->m_pNextZTreeValue;
	}
}
