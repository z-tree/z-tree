// PropSheetZTreeDemo.cpp : implementation file
//

#include "stdafx.h"
#include "ZTreeZMemoryPool.h"
#include "PropSheetZTreeDemo.h"


// CPropSheetZTreeDemo

IMPLEMENT_DYNAMIC(CPropSheetZTreeDemo, CPropertySheet)

CPropSheetZTreeDemo::CPropSheetZTreeDemo(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_propPageSort);
	m_propPageSort.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszSortTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Sort"));
    m_propPageSort.m_psp.pszTitle = m_wszSortTitle;

	AddPage(&m_propPageKeyValueMapping);
	m_propPageKeyValueMapping.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszKeyValueMappingTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Key-Value Mapping"));
    m_propPageKeyValueMapping.m_psp.pszTitle = m_wszKeyValueMappingTitle;
	
	AddPage(&m_propPageLongestCommonString);
	m_propPageLongestCommonString.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszLongestCommonStringTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Longest Common String"));
    m_propPageLongestCommonString.m_psp.pszTitle = m_wszLongestCommonStringTitle;
	
	AddPage(&m_propPageMemoryPool);
	m_propPageMemoryPool.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszMemoryPoolTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Memory Pool"));
    m_propPageMemoryPool.m_psp.pszTitle = m_wszMemoryPoolTitle;	

	MessageBox(_T("The demo application only supports UNIX/DOS ANSI/ASCII files. If you want it to work with UNICODE or MAC files, you need to change the code."));
}

CPropSheetZTreeDemo::CPropSheetZTreeDemo(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_propPageSort);
	m_propPageSort.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszSortTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Sort"));
    m_propPageSort.m_psp.pszTitle = m_wszSortTitle;

	AddPage(&m_propPageKeyValueMapping);
	m_propPageKeyValueMapping.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszKeyValueMappingTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Key-Value Mapping"));
    m_propPageKeyValueMapping.m_psp.pszTitle = m_wszKeyValueMappingTitle;
	
	AddPage(&m_propPageLongestCommonString);
	m_propPageLongestCommonString.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszLongestCommonStringTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Longest Common String"));
    m_propPageLongestCommonString.m_psp.pszTitle = m_wszLongestCommonStringTitle;
	
	AddPage(&m_propPageMemoryPool);	
	m_propPageMemoryPool.m_psp.dwFlags |= PSP_USETITLE;
	_snwprintf_s(m_wszMemoryPoolTitle, MAX_TITLE_LENGTH, MAX_TITLE_LENGTH, _T("Memory Pool"));
    m_propPageMemoryPool.m_psp.pszTitle = m_wszMemoryPoolTitle;

	MessageBox(_T("The demo application only supports UNIX/DOS ANSI/ASCII files. If you want it to work with UNICODE or MAC files, you need to change the code."));
}

CPropSheetZTreeDemo::~CPropSheetZTreeDemo()
{
}


BEGIN_MESSAGE_MAP(CPropSheetZTreeDemo, CPropertySheet)
	ON_COMMAND(ID_HELP, OnHelp)
END_MESSAGE_MAP()


// CPropSheetZTreeDemo message handlers
void CPropSheetZTreeDemo::OnHelp()
{
	// TODO: Add your command handler code here
	MessageBox(_T("For more infomation about Z-Tree document and source code, please refer to http://www.ztreesoft.com."));
}

