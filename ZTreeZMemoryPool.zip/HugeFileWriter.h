#pragma once

#include "ZTree\ZMemoryPool.h"

class CHugeFileWriter
{
public:
	CHugeFileWriter(void);
	~CHugeFileWriter(void);
private:
	CZMemoryPool m_memoryPool;
	unsigned char * m_pCache;
	unsigned Z_INT64 m_nCacheSize;
	unsigned Z_INT64 m_nCacheContentSize;
	
public:
	void InitCache(void);
	void DestroyCache(CFile& p_fileNewMapping);
	void Write(CFile& p_fileNewMapping, const void * lpBuf, UINT nCount);
};
