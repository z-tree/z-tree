#pragma once

#include "ZTree\ZTreeNoValue.h"
#include "ZTree\ZMemoryPool.h"
#include "HugeFileReader.h"
#include "HugeFileWriter.h"

class CSortFile
{
public:
	CSortFile(void);
	virtual ~CSortFile(void);

	//Call this function to sort source file and write results into the target file
	Z_INT64						SortInAscendingOrder(CString p_sSourceFileName, CString p_sTargetFileName);
	Z_INT64						SortInDescendingOrder(CString p_sSourceFileName, CString p_sTargetFileName);

	
	static unsigned char m_szCleanHeadBitsMask[ZTREE_BITS_NUMBER_PER_CHAR];
	//Read 50MB from the Source File Each Time.
	//This also assumes the maximum line length of a file is 50MB.
	static const Z_INT64		READ_FILE_BLOCK_SIZE = 1024 * 1024 * 50;
	Z_INT64						ReadFileIntoZTree(unsigned char * m_pLineBuffer, CString p_sSourceFileName, CZTreeNoValue& p_zTree);
	
	//Functions for writing sorting results
	void						GetValueFromKeyNode(unsigned char * m_pLineBuffer, unsigned int & p_nBufferIndexInBit, ZTREE_KEY_NODE * p_nZTreeShareKeys);
	void						GetValueFromBranchNode(unsigned char * m_pLineBuffer, unsigned int & p_nBufferIndexInBit, int p_nBitValue);
	Z_INT64						WriteResultInAscendingOrder(void * p_pNode, unsigned int p_nBufferIndexInBit);
	Z_INT64						WriteResultInDescendingOrder(void * p_pNode, unsigned int p_nBufferIndexInBit);


private:
	void GetErrorMessage(CString & p_sMessage);

	unsigned char *				m_pLineBuffer;
	unsigned int				m_nLineBufferSizeInBit;
	CFile						m_fileSortResult;
	CHugeFileWriter				m_hugeFileWriter; 
};
