// PropPageLongestCommonString.cpp : implementation file
//

#include "stdafx.h"
#include "ZTreeZMemoryPool.h"
#include "PropPageLongestCommonString.h"
#include "SortFile.h"


// CPropPageLongestCommonString dialog

IMPLEMENT_DYNAMIC(CPropPageLongestCommonString, CPropertyPage)

CPropPageLongestCommonString::CPropPageLongestCommonString()
	: CPropertyPage(CPropPageLongestCommonString::IDD)
{

}

CPropPageLongestCommonString::~CPropPageLongestCommonString()
{
}

void CPropPageLongestCommonString::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPropPageLongestCommonString, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_LOAC_FILE_INTO_Z_TREE, &CPropPageLongestCommonString::OnBnClickedBtnLoacFileIntoZTree)
	ON_EN_CHANGE(IDC_EDIT_TARGET_STRING, &CPropPageLongestCommonString::OnEnChangeEditTargetString)
END_MESSAGE_MAP()


// CPropPageLongestCommonString message handlers


BOOL CPropPageLongestCommonString::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	// TODO:  Add extra initialization here
	GetDlgItem(IDC_EDIT_TARGET_STRING)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_LONGEST_COMMON_SUBSTRING)->EnableWindow(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CPropPageLongestCommonString::OnBnClickedBtnLoacFileIntoZTree()
{
	// TODO: Add your control notification handler code here
	CFileDialog dlgFile(TRUE);
	if(dlgFile.DoModal() == IDOK)
	{
		CString sFileName = dlgFile.GetPathName();
		
		m_zTree.InitZTree();
	
		CSortFile loader;

		//1. Allocate Line Buffer
		CZMemoryPool memoryPool;
		unsigned char *	pLineBuffer = (unsigned char *)memoryPool.Malloc(CSortFile::READ_FILE_BLOCK_SIZE * 2);
	
		if(loader.ReadFileIntoZTree(pLineBuffer, sFileName, m_zTree) < 0)
		{
			memoryPool.Free(pLineBuffer);
			pLineBuffer = NULL;
			return;
		}
		memoryPool.Free(pLineBuffer);
		pLineBuffer = NULL;
		
		GetDlgItem(IDC_EDIT_TARGET_STRING)->EnableWindow(TRUE);

		MessageBox(_T("The file has been loaded into Z-Tree."));
	}
}
void CPropPageLongestCommonString::OnEnChangeEditTargetString()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CPropertyPage::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
	TCHAR wszKey[MAX_KEY_LENGTH];
	GetDlgItem(IDC_EDIT_TARGET_STRING)->GetWindowText(wszKey, MAX_KEY_LENGTH);
	//_snwprintf_s(wszKey, MAX_KEY_LENGTH, MAX_KEY_LENGTH, _T("%s"), p_sPassword);
	char szKey[MAX_KEY_LENGTH];
	int nKeyLen = WideCharToMultiByte(CP_ACP, 0, wszKey, (int)wcslen(wszKey), szKey, MAX_KEY_LENGTH, NULL, NULL);
	
	
	int nStrLength = m_zTree.GetLongestCommonBitNumber((unsigned char *)szKey, nKeyLen) / BITS_PER_CHAR;
	wszKey[nStrLength] = 0X00;

	GetDlgItem(IDC_EDIT_LONGEST_COMMON_SUBSTRING)->SetWindowText(wszKey);
}
